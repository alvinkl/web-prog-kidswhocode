<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Course - <?php echo e($course->name); ?></div>
    
                <div class="panel-body">
                    <!-- Gambaran aja nanti kayak gini tampilannya -->
                    <div>
                        <?php echo $course->description; ?>

                    </div>
                    <hr>
                    <ul class="list-group">
                        <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $exercise): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <a href="<?php echo e(route('user/exercise/show', $exercise->slug)); ?>">
                                <li class="list-group-item">
                                    <?php if($exercise->users->contains(auth()->user()->id)): ?>
                                        <!-- Menandakan sudah selesai-->
                                        <?php echo e(($no + 1) . '. ' . $exercise->name . ' - done'); ?>

                                    <?php else: ?>
                                        <?php echo e(($no + 1) . '. ' . $exercise->name); ?>

                                    <?php endif; ?>
                                </li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>

                <div class="panel-footer">
                    <a href="<?php echo e(route('user/courses/index')); ?>">Back to Course List</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>