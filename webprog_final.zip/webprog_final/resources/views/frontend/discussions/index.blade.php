@extends('layouts.master-frontend')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><a href="{{route('user/course', $exercise->course->slug)}}">{{$exercise->course->name}}</a> - <a href="{{ route('user/exercise/show', $exercise->slug) }}">{{$exercise->name}}</a> - Discussions - <a href="{{route('user/discussion/create', $exercise->slug)}}" class="btn btn-default">Create a New Discussion</a></div>

                <div class="panel-body">
                    @if($discussions->count() == 0)
                        <h3 class="text-center">Belum ada yang berdiskusi untuk tutorial ini...</h3>
                    @endif
                	<!-- Gambaran aja nanti kayak gini tampilannya -->
                    @foreach($discussions as $discussion)
                        <ul class="list-group">
                            
                                <li class="list-group-item">
                                    <a href="{{route('user/discussion/show', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id])}}">
                                        <h3>{{ $discussion->title }} {{ $discussion->is_deleted ? '- hidden' : ''}} {{ $discussion->is_closed ? '- closed' : ''}}</h3><br/>
                                    </a>
                                    <div style="text-align: right;">
                                        @if(auth()->user()->can('manage-discussion'))
                                            @if($discussion->is_deleted)
                                                <a href="{{route('user/discussion/unhide', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-eye-open"></i> Unhide</a>
                                            @else
                                                <a href="{{route('user/discussion/hide', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-eye-close"></i> Hide</a>
                                            @endif
                                            -
                                            @if($discussion->is_closed)
                                                <a href="{{route('user/discussion/unclose', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-ok"></i> Unclose</a>
                                            @else
                                               <a href="{{route('user/discussion/close', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-remove"></i> Close</a>
                                            @endif
                                            -
                                        @endif
                                        <em >oleh {{ $discussion->starter->username}}, pada tanggal {{ $discussion->created_at->format('d-m-Y, H:i:s') }}</em>
                                    </div>
                                </li>
                        </ul>
                        {{ $discussions->links() }}
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
