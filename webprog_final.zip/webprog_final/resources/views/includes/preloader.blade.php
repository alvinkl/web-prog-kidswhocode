<div id="overlay">
    <div class="spinner">
    </div>
    <div class="text">Loading...</div>
</div>