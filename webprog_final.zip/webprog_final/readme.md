Fitur- Fitur KidsWhoCode

1. Penjelasan dan contoh code disajikan dalam Bahasa Indonesia, sehingga memudahkan user dalam  pembelajaran.
2. Pembelajaran dibuat interaktif sehingga memberikan experience yang baru untuk user.
3. Game, bertujuan untuk mengasah kemampuan mengetik dari user, dan membuat user lebih cepat mengetik code.
4. Tampilan yang menarik dan easy to learning, memungkinkan user untuk tetap menggunakan aplikasi ini dalam waktu yang cukup lama.
5. Setiap exercise, dibuat forum diskusi untuk saling bertanya jawab dengan exercise. Sehingga bisa saling berinteraksi antar user 1 dengan user lainnya.
6. Sistem leveling yang kami sajikan, bertujuan untuk memacu niat belajar dari setiap user untuk terus belajar.
7. Sistem achievement, menampilkan peringkat dari setiap user, semakin banyak exercise yang diselesaikan maka akan semakin tinggi achievement yang didapat.
8. Moderator diskusi, yang berfungsi untuk menutup atau menghilangkan diskusi jika dinilai tidak layak.

INSTALASI

1. Pastikan anda memiliki PHP versi 7 ke atas, karena kami menggunakan Laravel 5.3 & anda memiliki koneksi ke internet, karena sebagian konten kami terdapat di internet (library, gambar dan sebagainya)

2. Pastikan anda memiliki DBMS Mysql / MariaDB, yang kami gunakan adalah yang terdapat pada XAMPP v3.2.1

3. Pastikan anda sudah melakukan setting environment variable untuk PHP (langkahnya terdapat disini : https://www.sitepoint.com/how-to-install-php-on-windows/)

4. Pastikan anda memiliki browser google chrome ataupun Mozilla

5. Setelah anda menginstall software-software tersebut, maka anda masuk ke direktori tempat anda meletakkan proyek kami

6. Nyalakan service MySQL dan Apache pada XAMPP (atau manual jika anda menginstalasinya secara manual.

7. Buka PHPMyAdmin (atau tools MySQL lainnya), kemudian import database yang telah kami sediakan dengan nama "laravel_web_prog.sql"

8. Di dalam root dari proyek kami, anda buka command line (CTRL + SHIFT + D, masukkan "cmd", tekan ENTER.

9. Masukkan "php artisan serve", jika berhasil seharusnya muncul :
  "Laravel development server started on http://localhost:8000/"

10. Sekarang website telah siap dijalankan, anda dapat mengaksesnya dengan masuk ke page : http://localhost:8000/

11. Kami telah menyediakan ID Admin :
    username : 3tagger & password : andri

12. Anda juga dapat membuat id sendiri dengan menekan tombol sign update

ps: Jika anda mendapatkan kesulitan dalam instalasi, mohon menghubungi kami melalui email ini : alvingunawan39@gmail.com atau 3tagger95@gmail.com 
