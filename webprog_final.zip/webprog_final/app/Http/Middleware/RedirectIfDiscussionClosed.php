<?php

namespace App\Http\Middleware;

use Closure;
use App\Discussion;

class RedirectIfDiscussionClosed
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $discussion = Discussion::find($request->discussionId);

        if(!auth()->user()->can('manage-discussion') && $discussion->is_closed) {
            abort(404);
        }
        return $next($request);
    }
}
