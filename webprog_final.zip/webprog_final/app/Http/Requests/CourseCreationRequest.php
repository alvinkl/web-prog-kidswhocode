<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CourseCreationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|unique:courses,name',
            'slug' => 'required|alpha_dash|unique:courses,slug',
            'course_topic_id' => 'required|exists:course_topics,id',
            'description' => 'required',
            'thumbnail' => 'required|mimes:png',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'name.required' => 'Name must not be empty',
            'name.unique' => 'Name already exists',
            'slug.required' => 'Slug must not be empty',
            'slug.alpha_dash' => 'Allowed slug characters : alphanumeric, dash or underscore',
            'slug.unique' => 'Slug already exists',
            'course_topic_id.required' => 'Topic course must be selected',
            'course_topic_id.exists' => 'Selected topic course does not exists',
            'description.required' => 'Description must not be empty',
            'thumbnail.required' => 'Thumbnail must not be empty',
            'thumbnail.mimes' => 'Thumbnail must be .png'
        ];
    }
}
