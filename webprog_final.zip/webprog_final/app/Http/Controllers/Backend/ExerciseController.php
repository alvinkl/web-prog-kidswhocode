<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\HTML;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\ExerciseCreationRequest;
use App\Http\Requests\ExerciseUpdateRequest;
use App\Exercise;
use App\Course;

use App\Helpers\Flash;

class ExerciseController extends Controller
{
    public function index() {

        $exercises = Exercise::all();

        return view('backend.exercises.index', compact([
            'exercises'
        ]));
    }

    public function create() {

        $courses = Course::all();

        //defining default value, in case of error happens
        $templateDefaultCode = "Default Code File does not exists, please check the public resources";
        $templateIframeCode = "Iframe Code File does not exists, please check the public resources";

        if(File::exists(public_path('html/template.html')))
            $templateIframeCode = File::get(public_path('html/template.html'));
        if(File::exists(public_path('html/default.html')))
            $templateDefaultCode = File::get(public_path('html/default.html'));

        return view('backend.exercises.create', compact([
            'courses',
            'templateIframeCode',
            'templateDefaultCode'
        ]));
    }

    public function edit($id) {

        $courses = Course::all();
        $exercise = Exercise::find($id);

        $currentIframeCode = "IFrame Code File does not exists, please check the public resources";

        //The IFrame file has the same name with the exercise name
        if(File::exists(public_path('html/' . $exercise->slug . '.html')))
            $currentIframeCode = File::get(public_path('html/' . $exercise->slug . '.html'));
        
        return view('backend.exercises.edit', compact([
            'exercise',
            'courses',
            'currentIframeCode'
        ]));

    }

    public function update(ExerciseUpdateRequest $request, $id) {

        $exercise = Exercise::findOrFail($id);

        if(File::exists(public_path('html/' . $exercise->slug . '.html'))) 
            File::delete(public_path('html/' . $exercise->slug . '.html'));

        $iframeFileName = $request->slug . '.html';

        File::put(public_path('html/' . $iframeFileName), $request->iframe_file);

        $exercise->name = $request->name;
        $exercise->slug = $request->slug;
        $exercise->default_code = $request->default_code;
        $exercise->course_id = $request->course_id;
        $exercise->description = e($request->description);
        $exercise->iframe_file = $iframeFileName;
        $exercise->experience_point = $request->experience_point;
        $exercise->ordering = $request->ordering;

        if($exercise->save())
            Flash::message('success', 'Exercise ' . $exercise->name . ' berhasil diupdate');
        else
            Flash::message('danger', 'Exercise ' . $exercise->name . ' gagal diupdate');

        return redirect()->route('exercise/edit', $exercise->id);

    }

    public function destroy($id) {

        $exercise = Exercise::findOrFail($id);
        File::delete(public_path('html/' . $exercise->name . '.html'));

        if($exercise->delete())
            Flash::message('success', 'Exercise ' . $exercise->name . ' berhasil dihapus');
        else
            Flash::message('danger', 'Exercise ' . $exercise->name . ' gagal dihapus');

        return redirect()->route('exercise/index');
    }

    public function store(ExerciseCreationRequest $request) {

        $iframeFileName = $request->slug . '.html';

        File::put(public_path('html/' . $iframeFileName), $request->iframe_file);

        $exercise = Exercise::create([
            'name' => $request->name,
            'slug' => $request->slug,
            'course_id' => $request->course_id,
            'description' => e(stripcslashes($request->description)),
            'default_code' => stripcslashes($request->default_code),
            'iframe_file' => $iframeFileName,
            'experience_point' => $request->experience_point,
            'ordering' => $request->ordering
        ]);

        if($exercise)
            Flash::message('success', 'Exercise ' . $exercise->name . ' berhasil dibuat');
        else
            Flash::message('danger', 'Exercise ' . $exercise->name . ' gagal dibuat');

        return redirect()->route('exercise/edit', $exercise->id);
    }
}
