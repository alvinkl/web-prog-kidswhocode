@extends('layouts.master-backend')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Course - Create</div>

                <div class="panel-body">
                    <form action="{{route('course/store')}}" method="POST" id="course-form" enctype="multipart/form-data">
                        {{csrf_field()}}

                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Course name here..." value="{{old('name')}}">
                            @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="slug" class="form-label">Slug</label>
                            <input type="text" name="slug" class="form-control" placeholder="Course Slug here..." value="{{old('slug')}}">
                            @if ($errors->has('slug'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('slug') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="course_topic_id" class="form-label">Course Topic</label>
                            <select name="course_topic_id" class="form-control">
                                @foreach($courseTopics as $courseTopic)
                                    <option value="{{$courseTopic->id}}">{{$courseTopic->name}}</option>
                                @endforeach
                            </select>
                            @if ($errors->has('course_topic_id'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('course_topic_id') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="10" placeholder="Enter the description here...">{{old('description')}}</textarea>
                            @if ($errors->has('description'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('description') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="thumbnail" class="form-label">thumbnail</label>
                            <input type="file" name="thumbnail" class="form-control">
                            @if ($errors->has('thumbnail'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('thumbnail') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Create</button>
                            <a href="{{route('course/index')}}" class="btn btn-default right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection