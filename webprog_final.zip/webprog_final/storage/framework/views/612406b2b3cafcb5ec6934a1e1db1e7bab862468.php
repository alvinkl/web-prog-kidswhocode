<?php $__env->startSection('content'); ?>
<div class='container-fluid con-buff'>
  <div class='row-fluid' id='selection'>
    <div class='col-sm-6 img-cont'>
        <?php if(Auth::check()): ?>
             <a href="<?php echo e(route('user/courses/index')); ?>"><div id='tutorial' style="background-image: url('<?php echo e(asset('image/tutorial-banner.jpg')); ?>'); "></div><h1>Tutorial</h1></a>
        <?php else: ?>
            <a href="<?php echo e(route('login/get')); ?>"><div id='tutorial' style="background-image: url('<?php echo e(asset('image/tutorial-banner.jpg')); ?>'); "></div><h1>Tutorial</h1></a>
        <?php endif; ?>
    </div>
    <div class='col-sm-6 img-cont'>
      <a href="<?php echo e(route('test/typing-game')); ?>"><div id='game' style="background-image: url('<?php echo e(asset('image/game-banner.jpg')); ?>');"></div><h1>Interactive Code</h1></a>

    </div>
  </div>
</div>

<div id='lessons'>
  <div class='row-fluid'>
    <div class='col-sm-4 lesson-cont'>
      <div id='html'></div>
      <h3>Mendesain website modern dan belajar cara menyeimbangkan tampilan untuk konten dan navigasi</h2>
    </div>
    <div class='col-sm-4 lesson-cont'>
        <div id='css'></div>
        <h3>Membuat tampilan menarik dengan gaya tersendiri dan tampilan responsif</h3>
    </div>
    <div class='col-sm-4 lesson-cont'>
        <div id='js'></div>
        <h3>Menarik perhatian pengunjung website dengan tampilan dinamis dan animasi yang menarik</h3>
    </div>
  </div>
</div>
<!-- 
  <div id='introduction'>
    <div class='row'>
      <div class='col-sm-6'>
        <h2>How can coding help you?</h2>
        <h4>Hear how Tommy went from knowing nothing about code to building one of Time's '50 Best Websites' after learning with Interactive Code.</h4>
      </div>
      <div class='col-sm-6'>
        <div id='player'></div>
      </div>
    </div>
  </div> -->

  <script src="<?php echo e(asset('js/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>