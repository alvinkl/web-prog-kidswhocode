<?php $__env->startSection('additional-style'); ?>
    <style>
        .show {
          display: block !important;
        }
        .hidden {
          display: none !important;
          visibility: hidden !important;
        }
        .invisible {
          visibility: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <a href="<?php echo e(route('user/course', $exercise->course->slug)); ?>"><?php echo e($exercise->course->name); ?></a> - <a href="<?php echo e(route('user/exercise/show', $exercise->slug)); ?>"><?php echo e($exercise->name); ?></a>
                <a href="<?php echo e(route('user/discussion/index', $exercise->slug)); ?>"> - Discussions
                </a> - <?php echo e($discussion->title); ?> <?php echo e($discussion->is_deleted ? '- hidden' : ''); ?> <?php echo e($discussion->is_closed ? '- closed' : ''); ?>

                <?php if(auth()->user()->can('manage-discussion')): ?>
                    - 
                    <?php if($discussion->is_deleted): ?>
                        <a href="<?php echo e(route('user/discussion/unhide', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-eye-open"></i> Unhide</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('user/discussion/hide', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-eye-close"></i> Hide</a>
                    <?php endif; ?>
                    -
                    <?php if($discussion->is_closed): ?>
                        <a href="<?php echo e(route('user/discussion/unclose', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-ok"></i> Unclose</a>
                    <?php else: ?>
                       <a href="<?php echo e(route('user/discussion/close', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-remove"></i> Close</a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>

                <div class="panel-body">
                    <?php $__currentLoopData = $discussionPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussionPost): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo e($discussionPost->user->username); ?><br/>
                                title: <?php echo e($discussionPost->user->title->name); ?>, level <?php echo e($discussionPost->user->level); ?>


                                <?php if($discussionPost->created_at != $discussionPost->updated_at): ?>
                                    <div style="text-align: right;"><?php echo e($discussionPost->created_at->format('d-m-Y h:i:s') . ', edited'); ?></div>
                                <?php else: ?>
                                    <div style="text-align: right;"><?php echo e($discussionPost->created_at->format('d-m-Y h:i:s')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="panel-body">
                                <pre style="font-family: helvetica; width: 100%; white-space: pre-line;"><?php echo e($discussionPost->content); ?></pre>
                            </div>
                            <?php if(auth()->user()->id == $discussionPost->user_id && !$discussion->is_closed): ?>
                                <div class="panel-footer">
                                    <button onclick="toggleEdit('<?php echo e('edit-form-' . $discussionPost->id); ?>')" class="btn btn-default">Edit</button>

                                    <!-- Untuk mengedit postingan diskusi -->
                                    <form action="<?php echo e(route('user/discussion-post/update', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id, 'discussionPostId' => $discussionPost->id ])); ?>" method="POST" id="<?php echo e('edit-form-' . $discussionPost->id); ?>" class="hidden">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('put')); ?>

                                        <p class="help-block"></p>
                                        <div class="form-group" id="group-reply">
                                            <textarea name="content" id="reply" placeholder="Masukkan editan anda disini..." class="form-control"/><?php echo e($discussionPost->content); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-default">Post Edit</button>
                                        </div>  
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>

                <div class="panel-footer">
                    <?php echo e($discussionPosts->links()); ?>

                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
                </div>
            </div>
            <?php if( !$discussion->is_closed  || auth()->user()->can('manage-discussion')): ?>
            <div class="panel panel-default">
                <div class="panel-heading">Reply</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('user/discussion-post/store', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id])); ?>" method="POST">
                         <?php echo e(csrf_field()); ?>

                        <div class="form-group" class="text-center">
                            <?php echo captcha_img(); ?>

                        </div>

                        <div class="form-group <?php echo e($errors->has('captcha') ? 'has-error' : ''); ?>" id="group-captcha">
                            <label for="captcha"></label>
                            <input type="text" name="captcha" id="captcha" placeholder="Masukkan captcha disini..." value="<?php echo e(old('captcha')); ?>" class="form-control"/>
                            <p class="help-block"><?php echo e($errors->first('captcha')); ?></p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>" id="group-reply">
                            <textarea name="content" id="reply" placeholder="Masukkan reply anda disini..." class="form-control"/><?php echo e(old('content')); ?></textarea>
                            <p class="help-block"><?php echo e($errors->first('content')); ?></p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Reply</button>
                        </div>                        
                    </form>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-script'); ?>
    <script>
    function toggleEdit(targetId) {
        $('#' + targetId).toggleClass('hidden');
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>