<h2>Contact Form Submission</h2>
<p>By: <?php echo e($contactMessage->name); ?></p>
<p>Email Address : <?php echo e($contactMessage->email); ?></p>
<pre>
	
	<?php echo e($contactMessage->message); ?>


</pre>