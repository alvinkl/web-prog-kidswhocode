@extends('layouts.master-frontend')

@section('additional-style')
    <style>
        #preview {
            height: 400px;
            width: 100%;
            border: solid 1px #C8C8C8;
        }

        #description {
            height: 300px;
            width: 100%;
            overflow: scroll;
        }

        #editor {
            width: 100%;
            height: 150px;
        }
    </style>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="{{route('user/course', $course->slug)}}">{{$course->name}}</a> - {{$exercise->name}}
                    <a href="{{ route('user/discussion/index', $exercise->slug) }}" class="btn btn-default">Discussion</a>
                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <h3>{{$exercise->name}}</h3>
                            <hr>
                            <div id="description">
                                {!! nl2br($exercise->description) !!}
                            </div>
                        </div>
                        <div class="col-md-8">
                            <iframe id="preview" frameborder="0" src="{{asset('html/' . $exercise->iframe_file)}}"></iframe>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <div id="editor"></div>
                            <hr>
                            <form action="{{route('user/exercise/store', $exercise->slug)}}" method="POST">
                                {{csrf_field()}}
                                <input type="hidden" id="user-code" name="user_code">
                                <button id="btn-next" class='btn btn-default' type='submit' disabled>Next</button>
                                <strong><em style="background-color: black; color: white; padding: 5px; border-radius: 50px;"> Perhatian : Untuk menjalankan code yang sudah dimasukkan, tekan shift + enter </em></strong>
                            </form>
                            <div class="pull-right">
                                <a href="{{route('user/course', $course->slug)}}">Back to the exercise list</a>
                            </div> 
                        </div>
                    </div>
                </div>

                <template id="hidden-default-code">{!!$user_code == null ? $exercise->default_code : $user_code!!}</template>
            </div>
        </div>
    </div>
</div>
@endsection

@section('additional-script')
   <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.5/ace.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.5/theme-monokai.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.5/mode-html.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.5/worker-html.js"></script>
    <script>
        $(document).ready(function() {
            //setting text editor
            var editor = ace.edit("editor");
            editor.resize();
            editor.setTheme("ace/theme/monokai");
            editor.getSession().setMode("ace/mode/html");
            editor.getSession().setUseWrapMode(true);
            editor.getSession().setUseWorker(false);

        	//setting preview
            var preview = document.getElementById('preview');

            preview.addEventListener("load", function() {
            	//setting default code
	            var hiddenDefaultCode = document.getElementById('hidden-default-code');
	            
	            //setting initial value
	            var frameDoc = preview.contentDocument || preview.contentWindow.document;

	            editor.setValue(hiddenDefaultCode.innerHTML);
	            frameDoc.getElementById('user-html').innerHTML = editor.getValue();
	            hiddenDefaultCode.innerHTML = "";
            });
            
            preview.src = '{{asset('html/' . $exercise->iframe_file)}}';

             $(window).keydown(function(e) {
              if (e.ctrlKey && e.keyCode == 13) {
                var frameDoc = preview.contentDocument || preview.contentWindow.document;
                var buttonNext = document.getElementById('btn-next');
                editorContent = editor.getValue();

                frameDoc.getElementById("user-html").innerHTML = editorContent;
                localStorage.code = editorContent;

                if (frameDoc.getElementById('error-msg').innerHTML === 'benar') {
                    setTimeout(() => buttonNext.className = 'btn btn-primary', 10);
                    buttonNext.disabled = false;
                    moveCode(editor, 'user-code');
                }
                else {
                    setTimeout(() => buttonNext.className = 'btn btn-default', 10);
                    buttonNext.disabled = true;
                }
              }
            })
        }); 

        function moveCode(from, to) {
            //from is ace code instance
            //to is HTML id
            var code = from.getValue();
            $("#" + to).val(code);
        }
    </script>
@endsection