<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    protected $fillable = ['name', 'slug','course_id','description','default_code','iframe_file','experience_point', 'ordering'];

    /**
     * Each course has many exercises
     */
    public function course() {
    	return $this->belongsTo(\App\Course::class);
    }

    /**
     * Completed exercises by user
     */
    public function users() {
        return $this->belongsToMany(\App\User::class, 'exercise_user', 'exercise_id', 'user_id')->withPivot('user_code');
    }

    /**
     * Each exercise can have multiple discussion
     */
    public function discussions() {
        return $this->hasMany(\App\Discussion::class);
    }
}
