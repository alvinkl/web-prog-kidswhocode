<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.frontend.head')
    @yield('additional-includes')
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Proyek Web Programming') }}</title>
    
    <!-- Scripts, CSRF protection -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

     <!-- Additional style -->
    @yield('additional-style')
</head>
<body>
    <!-- Preloader -->
    @include('includes.preloader')
    
    <div id="web-content"> 
        <!-- Navigation Bar -->
        @include('includes.frontend.navigation')
        
        <!-- Flash message for notification -->
        @include('includes.others.flash')

        <!-- Content -->
        @yield('content')

        <!-- Footer -->
        @include('includes.frontend.footer')

        <!-- Scripts -->
        @include('includes.frontend.script')

        <!-- Additional script -->
        @yield('additional-script')
    </div>
    
</body>
</html>
