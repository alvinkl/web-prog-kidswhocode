<html>
<head>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
    <link rel="stylesheet prefetch" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel='stylesheet' href='{{asset('css/style.css')}}'>
    <link rel="stylesheet" href="{{asset('css/code.css')}}">
    <link rel="stylesheet" href="{{asset('css/footer.css')}}">

</head>
<body>
    <nav id='navbar' class='navdefault'>
        <div class="row">
            <div class="col-sm-1"></div>
            <a href="" class='color-buff'><div class="col-sm-2" id='tutorials-library'>TUTORIALS LIBRARY</div></a>
            <a href="" class='color-buff'><div class="col-sm-2" id='coding-ground'>CODING GROUND</div></a>
            <a href=""><div class="col-sm-2" id='logo'><div id='logoimg'></div></div></a>
            <a href="" class='color-buff'><div class="col-sm-2" id='Examples'>EXAMPLES</div></a>
            <a href="" class='color-buff'><div class="col-sm-2" id='References'>REFERENCES</div></a>
            <div class="col-sm-1"></div>
        </div>
    </nav>

    <div id='parallax'></div>

    <div class='container-fluid top-buff'>

        <div class="tutorial-content">
            <div class='text-center' id="title">
                <h1>HTML</h1>
                <h4>The language for building web pages</h4>
            </div>
            <div id="content">
                <p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
<p>HTML (HyperText Markup Language) adalah  sebuah bahasa standar yang digunakan
oleh browser internet untuk membuat halaman dan dokumen pada sebuah Web yang kemudian dapat diakses dan dibaca layaknya sebuah artikel.</p>
            </div>
        </div>

        <div class="code-content">
            <h1 class='text-center'>Code Time!</h1>
            <div id="code">
                <div id="editor"></div>
            	<iframe id="preview" frameborder="0" src="{{asset('html/exercise_test.html')}}"></iframe>
            	<div id="button-next" class='wrong'>
            		<button type='submit' disabled>Next</button>
            	</div>
            </div>
        </div>
    </div>

    <footer class="footer-distributed">

      <div clas='footer-left'>
        <p class="footer-links">
          <a href="#">Home</a>
          ·
          <a href="#">Blog</a>
          ·
          <a href="#">Pricing</a>
          ·
          <a href="#">About</a>
          ·
          <a href="#">Faq</a>
          ·
          <a href="#">Contact</a>
        </p>
      </div>


      <div class="footer-icons">

        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-github"></i></a>

      </div>


      <div class="footer-left">


        <p class="footer-company-name">BINUS UNIVERSITY</p>
        <p class="footer-company-name">Email: Interactive_code@email.com</p>
        <p class="footer-company-name"><strong>Interactive Code © 2016</strong></p>

      </div>

    </footer>

    <script src="{{asset('js/expect.js')}}"></script>
    <script src="{{asset('js/jquery.js')}}"></script>
    <script src="{{asset('js/jquery.expect.min.js')}}"></script>
    <script src="{{asset('js/ace/ace.js')}}"></script>
    <script src="{{asset('js/ace/theme-monokai.js')}}"></script>
    <script src="{{asset('js/ace/mode-html.js')}}"></script>
    <script src="{{asset('js/ace/worker-html.js')}}"></script>
    <script src="{{asset('js/script.js')}}"></script>
</body>
</html>
