<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Http\Requests\DiscussionCreationRequest;

use App\Exercise;
use App\Discussion;
use App\DiscussionPost;

class DiscussionController extends Controller
{
    public function index($exerciseSlug) {
    	
    	$exercise = Exercise::with(['discussions', 'course'])->where('slug', $exerciseSlug)->first();
    	$user = auth()->user();
    	$discussion = null;

    	if($user->can('manage-discussion')) {
    		$discussions = $exercise->discussions()
    							->with('starter')
                                ->orderBy('updated_at', 'desc')
    							->paginate(10);	
    	}
    	else {
    		$discussions = $exercise->discussions()
    							->with('starter')
    							->where('is_deleted', false)
    							->orderBy('updated_at', 'desc')
                                ->paginate(10);	
    	}

    	return view('frontend.discussions.index', compact([
    		'exercise',
    		'discussions'
    	]));

    }

    public function show($exerciseSlug, $discussionId) {

        $user = auth()->user();

        $exercise = Exercise::where('slug', $exerciseSlug)->first();

        $discussion = Discussion::find($discussionId);

        if(!$user->can('manage-discussion') && $discussion->is_deleted) {
            abort(404);
        }

        $discussionPosts = DiscussionPost::with('user')->where('discussion_id', $discussionId)->paginate(10);

        return view('frontend.discussions.show', compact([
            'exercise',
            'discussion',
            'discussionPosts'
        ]));

    }

    public function create($exerciseSlug) {

    	$exercise = Exercise::where('slug', $exerciseSlug)->first();

    	return view('frontend.discussions.create', compact([
    		'exercise'
    	]));

    }

    public function store(DiscussionCreationRequest $request, $exerciseSlug) {

    	$exercise = Exercise::where('slug', $exerciseSlug)->first();

        $user = auth()->user();

    	$discussion = Discussion::create([
    		'user_id' => $user->id,
    		'exercise_id' => $exercise->id,
    		'title' => $request->title
    	]);

        $discussionPost = DiscussionPost::create([
            'discussion_id' => $discussion->id,
            'user_id' => $user->id,
            'content' => $request->content
        ]);

        return redirect()->route('user/discussion/show', [
            'exerciseSlug' => $exerciseSlug,
            'discussionId' => $discussion->id
        ]);
    }

    /**
     * Not deleting the data, only hides it
     */
    public function hide($exerciseSlug, $discussionId) {

    	$discussion = Discussion::find($discussionId);
    	$discussion->hide();

    	return redirect()->route('user/discussion/index', $exerciseSlug);
    }

    public function unhide($exerciseSlug, $discussionId) {

        $discussion = Discussion::find($discussionId);
        $discussion->unhide();

        return redirect()->route('user/discussion/index', $exerciseSlug);
    }

    public function close($exerciseSlug, $discussionId) {

        $discussion = Discussion::find($discussionId);
        $discussion->close();

        return redirect()->route('user/discussion/index', $exerciseSlug);
    }

    public function unclose($exerciseSlug, $discussionId) {

        $discussion = Discussion::find($discussionId);
        $discussion->unclose();

        return redirect()->route('user/discussion/index', $exerciseSlug);
    }    
}
