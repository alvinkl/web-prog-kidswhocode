<link rel="stylesheet" href="<?php echo e(asset('css/signup.css')); ?>">
<?php $__env->startSection('content'); ?>

<div class="buffer container-fluid">
    <form class='text-center' role="form" method="POST" action="<?php echo e(url('/register')); ?>">
    <?php echo e(csrf_field()); ?>

      <h3>Sign Up</h3>
      <hr>

        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <input type="text" class="form-control" placeholder="Full Name" id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
            <?php if($errors->has('name')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
            <input type="text" class="form-control" placeholder="Username" id="username" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
            <?php if($errors->has('username')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('username')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <input id="email" placeholder="Email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
            <input id="password-confirm" type="password" placeholder="Confirm Password" class="form-control" name="password_confirmation" required>
            <?php if($errors->has('password_confirmation')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-login">Sign up</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>