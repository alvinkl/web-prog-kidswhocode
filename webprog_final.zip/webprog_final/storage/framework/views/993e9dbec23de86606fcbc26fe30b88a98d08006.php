<?php $__env->startSection('additional-style'); ?>
    <style>
        .show {
          display: block !important;
        }
        .hidden {
          display: none !important;
          visibility: hidden !important;
        }
        .invisible {
          visibility: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Discussions - <a href="<?php echo e(route('user/discussion/index', $exercise->slug)); ?>"><?php echo e($exercise->name); ?></a> - <?php echo e($discussion->title); ?></a></div>

                <div class="panel-body">
                    <?php $__currentLoopData = $discussionPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussionPost): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo e($discussionPost->user->username); ?><br/>
                                title: <?php echo e($discussionPost->user->title->name); ?>, level <?php echo e($discussionPost->user->level); ?>


                                <?php if($discussionPost->created_at != $discussionPost->updated_at): ?>
                                    <div style="text-align: right;"><?php echo e($discussionPost->created_at->format('d-m-Y h:i:s') . ', edited'); ?></div>
                                <?php else: ?>
                                    <div style="text-align: right;"><?php echo e($discussionPost->created_at->format('d-m-Y h:i:s')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="panel-body">
                                <?php echo e($discussionPost->content); ?>

                            </div>
                            <?php if(auth()->user()->id == $discussionPost->user_id): ?>
                                <div class="panel-footer">
                                    <button onclick="toggleEdit('<?php echo e('edit-form-' . $discussionPost->id); ?>')" class="btn btn-default">Edit</button>

                                    <!-- Untuk mengedit postingan diskusi -->
                                    <form action="<?php echo e(route('user/discussion-post/update', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id, 'discussionPostId' => $discussionPost->id ])); ?>" method="POST" id="<?php echo e('edit-form-' . $discussionPost->id); ?>" class="hidden">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('put')); ?>

                                        <p class="help-block"></p>
                                        <div class="form-group" id="group-reply">
                                            <textarea name="content" id="reply" placeholder="Masukkan editan anda disini..." class="form-control"/><?php echo e($discussionPost->content); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-default">Post Edit</button>
                                        </div>  
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>

                <div class="panel-footer">
                    <?php echo e($discussionPosts->links()); ?>

                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">Reply</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('user/discussion-post/store', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id])); ?>" method="POST">
                         <?php echo e(csrf_field()); ?>

                        <div class="form-group" class="text-center">
                            <?php echo captcha_img(); ?>

                        </div>

                        <div class="form-group <?php echo e($errors->has('captcha') ? 'has-error' : ''); ?>" id="group-captcha">
                            <label for="captcha"></label>
                            <input type="text" name="captcha" id="captcha" placeholder="Masukkan captcha disini..." value="<?php echo e(old('captcha')); ?>" class="form-control"/>
                            <p class="help-block"><?php echo e($errors->first('captcha')); ?></p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>" id="group-reply">
                            <textarea name="content" id="reply" placeholder="Masukkan reply anda disini..." class="form-control"/><?php echo e(old('content')); ?></textarea>
                            <p class="help-block"><?php echo e($errors->first('content')); ?></p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Reply</button>
                        </div>                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-script'); ?>
    <script>
    function toggleEdit(targetId) {
        $('#' + targetId).toggleClass('hidden');
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>