<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;

use App\Helpers\Flash;

use App\Title;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\TitleCreationRequest;
use App\Http\Requests\TitleUpdateRequest;

class TitleController extends Controller
{
    public function index() {

        $titles = Title::all();

    	return view('backend.titles.index', compact([
            'titles'
        ]));
    }

    public function create() {

        return view('backend.titles.create');

    }

    public function edit($id) {

        $title = Title::findOrFail($id);

        return view('backend.titles.edit', compact([
            'title'
        ]));

    }

    public function update(TitleUpdateRequest $request, $id) {
        $title = Title::findOrFail($id);
        $title->name = $request->name;
        $title->level = $request->level;
        

        if($title->save())
            Flash::message('success', 'Title ' . $title->name . ' berhasil diupdate');
        else
            Flash::message('danger', 'Title ' . $title->name . ' gagal diupdate');

        return redirect()->route('title/index');
    }

    public function destroy($id) {

        $title = Title::findOrFail($id);        
        $title->delete();

        return redirect()->route('title/index');
    }

    public function store(TitleCreationRequest $request) {

    	$title = Title::create([
    		'name' => $request->name,
    		'level' => $request->level
    	]);

        if($title)
            Flash::message('success', 'Title ' . $title->name . ' berhasil dibuat');
        else
            Flash::message('danger', 'Course ' . $title->name . ' gagal dibuat');

    	return redirect()->route('title/index');

    }
}
