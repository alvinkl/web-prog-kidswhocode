<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = ['name', 'slug', 'description', 'course_topic_id'];

    public function course_topic() {
    	return $this->belongsTo(\App\CourseTopic::class);
    }

    public function exercises() {
    	return $this->hasMany(\App\Exercise::class);
    }

    public function exercisesCount() {
    	return $this->hasMany(\App\Exercise::class)->count();
    }

    public function isCompleted($user) {

        $completedExerciseCount = $user->exercisesCountByCourseId($this->id);
        $numOfExercises = $this->exercisesCount();

        return $completedExerciseCount == $numOfExercises && !$user->hasAchievement(\App\Achievement::where('name', $this->name)->first()->id);
    }
}
