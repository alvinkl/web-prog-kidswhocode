@extends('layouts.master-frontend')

@section('additional-style')
    <style>
        .show {
          display: block !important;
        }
        .hidden {
          display: none !important;
          visibility: hidden !important;
        }
        .invisible {
          visibility: hidden;
        }
    </style>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <a href="{{route('user/course', $exercise->course->slug)}}">{{$exercise->course->name}}</a> - <a href="{{ route('user/exercise/show', $exercise->slug) }}">{{$exercise->name}}</a>
                <a href="{{route('user/discussion/index', $exercise->slug) }}"> - Discussions
                </a> - {{ $discussion->title }} {{ $discussion->is_deleted ? '- hidden' : ''}} {{ $discussion->is_closed ? '- closed' : ''}}
                @if(auth()->user()->can('manage-discussion'))
                    - 
                    @if($discussion->is_deleted)
                        <a href="{{route('user/discussion/unhide', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-eye-open"></i> Unhide</a>
                    @else
                        <a href="{{route('user/discussion/hide', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-eye-close"></i> Hide</a>
                    @endif
                    -
                    @if($discussion->is_closed)
                        <a href="{{route('user/discussion/unclose', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-ok"></i> Unclose</a>
                    @else
                       <a href="{{route('user/discussion/close', [$exercise->slug, $discussion->id])}}" class="btn btn-default"><i class="glyphicon glyphicon-remove"></i> Close</a>
                    @endif
                @endif
                </div>

                <div class="panel-body">
                    @foreach($discussionPosts as $discussionPost)
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                {{$discussionPost->user->username}}<br/>
                                title: {{$discussionPost->user->title->name}}, level {{$discussionPost->user->level}}

                                @if($discussionPost->created_at != $discussionPost->updated_at)
                                    <div style="text-align: right;">{{$discussionPost->created_at->format('d-m-Y h:i:s') . ', edited'}}</div>
                                @else
                                    <div style="text-align: right;">{{$discussionPost->created_at->format('d-m-Y h:i:s')}}</div>
                                @endif
                            </div>
                            <div class="panel-body">
                                <pre style="font-family: helvetica; width: 100%; white-space: pre-line;">{{ $discussionPost->content }}</pre>
                            </div>
                            @if(auth()->user()->id == $discussionPost->user_id && !$discussion->is_closed)
                                <div class="panel-footer">
                                    <button onclick="toggleEdit('{{ 'edit-form-' . $discussionPost->id }}')" class="btn btn-default">Edit</button>

                                    <!-- Untuk mengedit postingan diskusi -->
                                    <form action="{{route('user/discussion-post/update', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id, 'discussionPostId' => $discussionPost->id ])}}" method="POST" id="{{'edit-form-' . $discussionPost->id}}" class="hidden">
                                        {{ csrf_field() }}
                                        {{ method_field('put') }}
                                        <p class="help-block"></p>
                                        <div class="form-group" id="group-reply">
                                            <textarea name="content" id="reply" placeholder="Masukkan editan anda disini..." class="form-control"/>{{ $discussionPost->content }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-default">Post Edit</button>
                                        </div>  
                                    </form>
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>

                <div class="panel-footer">
                    {{ $discussionPosts->links() }}
                    <a href="{{ url()->previous() }}" class="btn btn-default">Back</a>
                </div>
            </div>
            @if( !$discussion->is_closed  || auth()->user()->can('manage-discussion'))
            <div class="panel panel-default">
                <div class="panel-heading">Reply</div>
                <div class="panel-body">
                    <form action="{{route('user/discussion-post/store', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id])}}" method="POST">
                         {{ csrf_field() }}
                        <div class="form-group" class="text-center">
                            {!! captcha_img() !!}
                        </div>

                        <div class="form-group {{ $errors->has('captcha') ? 'has-error' : '' }}" id="group-captcha">
                            <label for="captcha"></label>
                            <input type="text" name="captcha" id="captcha" placeholder="Masukkan captcha disini..." value="{{ old('captcha') }}" class="form-control"/>
                            <p class="help-block">{{ $errors->first('captcha') }}</p>
                        </div>
                        <div class="form-group {{ $errors->has('content') ? 'has-error' : '' }}" id="group-reply">
                            <textarea name="content" id="reply" placeholder="Masukkan reply anda disini..." class="form-control"/>{{ old('content') }}</textarea>
                            <p class="help-block">{{ $errors->first('content') }}</p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Reply</button>
                        </div>                        
                    </form>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('additional-script')
    <script>
    function toggleEdit(targetId) {
        $('#' + targetId).toggleClass('hidden');
    }
    </script>
@endsection
