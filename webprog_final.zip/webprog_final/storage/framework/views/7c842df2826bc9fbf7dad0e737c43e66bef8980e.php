<?php $__env->startSection('content'); ?>
<div class="container">

    <ul class="nav nav-tabs md-pills pills-default" role="tablist">
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#excercise" role="tab"><i class="fa fa-graduation-cap fa-2x"></i> Courses</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#discussion" role="tab"><i class="fa fa-users fa-2x"></i> Diskusi Terbaru</a>
        </li>
      </ul>
      <div class="tab-content">
          <div class="tab-pane fade in active" id="excercise" role="tabpanel">
            <div class="panel-body">
              <div class="media">
                <div class="media-left media-middle">
                  <a href="#">
                    <img class="media-object media-img d-flex mr-3" src="<?php echo e(asset('image/' . $course->slug . '.png')); ?>" alt="html5" style="height: 128px;width: 128px;">
                  </a>
                </div>
                <div class="media-body">
                   <div class="panel-heading"> <a href="<?php echo e(route('user/courses/index')); ?>">Course</a> - <?php echo e($course->name); ?></div>
                   <div>
                        <?php echo $course->description; ?>

                    </div>
                    <hr>
                    <ul class="list-group">
                        <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $exercise): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <a href="<?php echo e(route('user/exercise/show', $exercise->slug)); ?>">
                                <li class="list-group-item">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <?php if($exercise->users->contains(auth()->user()->id)): ?>
                                                <!-- Menandakan sudah selesai-->
                                                <?php echo e(($no + 1) . '. ' . $exercise->name . ' - done'); ?>

                                            <?php else: ?>
                                                <?php echo e(($no + 1) . '. ' . $exercise->name); ?>

                                            <?php endif; ?>        
                                        </div>
                                        <div class="col-md-2">
                                            <div style="text-align: right;">
                                                <a href="<?php echo e(route('user/discussion/index', $exercise->slug)); ?>" class="btn btn-default">Discussion</a>
                                            </div>  
                                        </div>
                                    </div>
                                </li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>

                <div class="panel-footer">
                    <a href="<?php echo e(route('user/courses/index')); ?>">Kembali ke Courses List</a>
                </div>
                </div>
              </div>
            </div>
          <div class="tab-pane fade" id="discussion" role="tabpanel">
            <div class="panel-heading">Diskusi Terbaru - <?php echo e($course->name); ?></div>

                <div class="panel-body">
                    <?php if($latestDiscussions->count() == 0): ?>
                        <h3 class="text-center">Belum ada yang berdiskusi untuk course ini...</h3>
                    <?php endif; ?>

                    <!-- Gambaran aja nanti kayak gini tampilannya -->
                    <?php $__currentLoopData = $latestDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <ul class="list-group">
                                <a href="<?php echo e(route('user/discussion/show', ['exerciseSlug' => $discussion->exercise_slug, 'discussionId' => $discussion->discussion_id])); ?>">
                                    <li class="list-group-item">
                                        <span><?php echo e($discussion->exercise_name); ?> - </span>                                    
                                        <span><?php echo e($discussion->title); ?> <?php echo e($discussion->is_deleted ? '- hidden' : ''); ?> <?php echo e($discussion->is_closed ? '- closed' : ''); ?></span>
                                        <em style="text-align: right; float: right; color: black;"><?php echo e($discussion->username); ?>, <?php echo e((new DateTime($discussion->created_at))->format('d-m-Y, H:i:s')); ?></em>
                                    </li>
                                </a>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
          </div>
      </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>