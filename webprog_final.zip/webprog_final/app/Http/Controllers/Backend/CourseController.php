<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Input;

use Intervention\Image\Facades\Image;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\Flash;

use App\Course;
use App\CourseTopic;
use App\Exercise;

use App\Http\Requests\CourseUpdateRequest;
use App\Http\Requests\CourseCreationRequest;

class CourseController extends Controller
{
    public function index() {

        $courses = Course::with('course_topic')->get();

        return view('backend.courses.index', compact([
            'courses'
        ]));

    }

    public function create() {

        $courseTopics = CourseTopic::all();

        return view('backend.courses.create', compact([
            'courseTopics'
        ]));

    }

    public function edit($id) {
        
        $courseTopics = CourseTopic::all();
        $course = Course::find($id);

        return view('backend.courses.edit', compact([
            'course',
            'courseTopics'
        ]));

    }

    public function update(CourseUpdateRequest $request, $id) {

        $course = Course::find($id);
        $course->name = $request->name;
        $course->slug = $request->slug;
        $course->description = $request->description;
        $course->course_topic_id = $request->course_topic_id;

        if(Input::file('thumbnail')) {
            $thumbnail = Input::file('thumbnail');
            $filename = $course->slug . '.' . $thumbnail->getClientOriginalExtension();
            $destination = public_path('image/' . $filename);

            //Delete unused old image
            if(File::exists(public_path('image/' . $filename))) 
                File::delete(public_path('image/' . $filename));

            //Creating resized image
            Image::make($thumbnail->getRealPath())->resize(64, 64)->save($destination);
        }

        if($course->save())
            Flash::message('success', 'Course ' . $course->name . ' berhasil diupdate');
        else
            Flash::message('danger', 'Course ' . $course->name . ' gagal diupdate');

        return redirect()->route('course/edit', $course->id);

    }

    public function destroy($id) {

        $course = Course::with('exercises')->find($id);
        $exercises = $course->exercises;
        $filename  = $course->slug . '.png';

        //Deleting exercise files
        foreach($exercises as $exercise) {
            File::delete(public_path('html/' . $exercise->name . '.html'));
            $exercise->delete();
        }

        //Deleting image files
        if(File::exists(public_path('image/' . $filename))) 
            File::delete(public_path('image/' . $filename));

        if($course->delete())
            Flash::message('success', 'Course ' . $course->name . ' berhasil dihapus');
        else
            Flash::message('danger', 'Course ' . $course->name . ' gagal dihapus');

        return redirect()->route('course/index');

    }

    public function store(CourseCreationRequest $request) {

        $thumbnail = Input::file('thumbnail');
        $filename = $request->slug . '.' . $thumbnail->getClientOriginalExtension();
        $destination = public_path('image/' . $filename);

        //Creating resized image
        Image::make($thumbnail->getRealPath())->resize(64, 64)->save($destination);

        $course = Course::create([
            'name' => $request->name,
            'slug' => $request->slug,
            'description' => $request->description,
            'course_topic_id' => $request->course_topic_id
        ]);

        if($course)
            Flash::message('success', 'Course ' . $course->name . ' berhasil dibuat');
        else
            Flash::message('danger', 'Course ' . $course->name . ' gagal dibuat');

        return redirect()->route('course/edit', $course->id);

    }
}
