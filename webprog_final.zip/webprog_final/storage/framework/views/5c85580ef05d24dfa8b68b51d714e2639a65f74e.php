<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="nav nav-tabs md-pills pills-default" role="tablist">
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#excercise" role="tab"><i class="fa fa-graduation-cap fa-2x"></i> Courses</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#discussion" role="tab"><i class="fa fa-users fa-2x"></i> Diskusi Terbaru</a>
        </li>
    </ul>

    <div class="tab-content">
          <div class="tab-pane fade in active" id="excercise" role="tabpanel">
             <?php $__currentLoopData = $courseTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseTopic): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="panel-body">
              <div class="media">
                <div class="media-left media-middle">
                  <a href="#">
                    <img class="media-object media-img d-flex mr-3" src="<?php echo e(asset('image/' . $courseTopic->name . '.png')); ?>" alt="html5" style="height: 128px;width: 128px;">

                    <!-- Imagenya download, taro di public/image, terus kasih nama html.png sama css.png aja, biar nanti klo mo load image langsung berdasarkan nama courseya (inget case sensitve-->
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading"><?php echo e($courseTopic->name); ?></h4>
                  
                    <hr>
                    <ul class="list-group">
                        <?php $__currentLoopData = $courseTopic->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <a href="<?php echo e(route('user/course', $course->slug)); ?>">
                                <li class="list-group-item">
                                    <img style="width: 25px; height: 25px;" src="<?php echo e(asset('image/' . $course->slug . '.png')); ?>"> <?php echo e($course->name); ?>

                                </li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            
          <div class="tab-pane fade" id="discussion" role="tabpanel">
            <div class="panel-body">
              <?php if($latestDiscussions->count() == 0): ?>
                    <h3 class="text-center">Belum ada yang berdiskusi saat ini...</h3>
                <?php endif; ?>

                <!-- Gambaran aja nanti kayak gini tampilannya -->
                <?php $__currentLoopData = $latestDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <ul class="list-group">
                        <a href="<?php echo e(route('user/discussion/show', ['exerciseSlug' => $discussion->exercise->slug, 'discussionId' => $discussion->id])); ?>">
                            <li class="list-group-item">
                                <span><?php echo e($discussion->exercise->course->name); ?> - </span>                                    
                                <span><?php echo e($discussion->title); ?>  <?php echo e($discussion->is_deleted ? '- hidden' : ''); ?> <?php echo e($discussion->is_closed ? '- closed' : ''); ?></span>
                                <em style="text-align: right; float: right; color: black;"><?php echo e($discussion->starter->username); ?>, <?php echo e($discussion->created_at->format('d-m-Y, H:i:s')); ?></em>
                            </li>
                        </a>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
          </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>