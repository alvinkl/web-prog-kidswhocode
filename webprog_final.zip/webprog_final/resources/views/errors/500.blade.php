@extends('layouts.master-frontend')

@section('content')
    <div class="container">
        <div class="content">
            Error on our server, <a href="{{ route('index') }}">Click here</a> to go to index
        </div>
    </div>
@endsection