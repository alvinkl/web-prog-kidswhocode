<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ExerciseUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

     /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|unique:exercises,name,' . $this->id . ',id',
            'slug' => 'required|alpha_dash|unique:exercises,slug,' . $this->id . ',id',
            'course_id' => 'required|exists:courses,id',
            'description' => 'required',
            'iframe_file' => 'required',
            'experience_point' => 'numeric|min:50',
            'ordering' => 'unique:exercises,ordering,' . $this->id . ',id,course_id,' . $this->course_id
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'name.required' => 'Name must not be empty',
            'name.unique' => 'Name already exists',
            'slug.required' => 'Slug must not be empty',
            'slug.alpha_dash' => 'Allowed slug characters : alphanumeric, dash or underscore',
            'slug.unique' => 'Slug already exists',
            'course_id.required' => 'Course must be selected',
            'course_id.exists' => 'Selected course does not exists',
            'description.required' => 'Description must not be empty',
            'iframe_file.required' => 'IFrame file code must not be empty',
            'experience_point.numeric' => 'Experience Point must be numerical',
            'experience_point.min' => 'Experience Point at least 50 points',
            'ordering.unique' => 'ordering must be unique to each course'
        ];
    }
}
