<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

// Home routes...
Route::get('/', [
	'as' 	=> 'index',
	'uses'	=> 'PageController@index'
]);

//Contact us routes...
Route::get('/contact', [
	'as'	=> 'contact/get',
	'uses'	=> 'PageController@showContactForm'
]);

Route::post('/contact', [
	'as'	=> 'contact/post',
	'uses'	=> 'PageController@contact'
]);

Route::get('/typing', [
	'as'	=> 'test/typing-game',
	'uses'	=> 'PageController@typing'
]);

Route::get('/typing/update-score', [
	'as'	=> 'typing/update-score',
	'uses'	=> 'PageController@updateScore'
]);

Route::get('/typing/get-words', [
	'as'	=> 'typing/get-words',
	'uses'	=> 'PageController@getWords'
]);

Route::get('/test-file', [
	'as' => 'test',
	'uses' => 'PageController@test'
]);

//Auth::routes(); --> default login route

// Authentication Routes...
Route::get('login', [
	'as'	=> 'login/get',
	'uses'  =>'Auth\LoginController@showLoginForm'
]);
Route::post('login', [
	'as'   => 'login/post',
	'uses' => 'Auth\LoginController@login'
]);
Route::post('logout', [
	'as'   => 'logout/post',
	'uses' => 'Auth\LoginController@logout'
]);

// Registration Routes...
Route::get('register', [
	'as'   => 'register/get',
	'uses' => 'Auth\RegisterController@showRegistrationForm'
]);
Route::post('register', [
	'as'   => 'register/post',
	'uses' => 'Auth\RegisterController@register'
]);

// Password Reset Routes...
Route::get('password/reset', [
	'as'   => 'password/reset/get',
	'uses' => 'Auth\ForgotPasswordController@showLinkRequestForm'
]);
Route::post('password/email', [
	'as'   => 'password/send-email',
	'uses' => 'Auth\ForgotPasswordController@sendResetLinkEmail'
]);
Route::get('password/reset/{token}', [
	'as'   => 'password/reset/reply/get',
	'uses' => 'Auth\ResetPasswordController@showResetForm'
]);
Route::post('password/reset', [
	'as'   => 'password/reset/reply/post',
	'uses' => 'Auth\ResetPasswordController@reset'
]);

Route::group(['prefix' => 'user'], function() {
	Route::get('/', [
		'as' 	=> 'user/index',
		'uses'	=> 'Frontend\UserController@index'
	]);
});

//Registered
Route::group(['middleware' => 'permission:do-courses'], function() {
	Route::get('course', [
		'as' => 'user/courses/index',
		'uses' => 'Frontend\CourseController@index'
	]);
	Route::get('course/{courseSlug}', [
		'as' => 'user/course',
		'uses' => 'Frontend\CourseController@show'
	]);
	Route::get('exercise/{exerciseSlug}', [
		'as'	=> 'user/exercise/show',
		'uses'	=> 'Frontend\ExerciseController@show'
	]);
	Route::post('exercise/{exerciseSlug}', [
		'as'	=> 'user/exercise/store',
		'uses'	=> 'Frontend\ExerciseController@store'
	]);
});

Route::group(['middleware' => 'permission:manage-discussion'], function() {
	/**
	 * Disini akan diisi dengan wewenang moderator (moderator dan admin akan digabung)
	 */
	Route::get('discussion/{exerciseSlug}/{discussionId}/close', [
		'as' => 'user/discussion/close',
		'uses' => 'Frontend\DiscussionController@close'
	]);
	Route::get('discussion/{exerciseSlug}/{discussionId}/unclose', [
		'as' => 'user/discussion/unclose',
		'uses' => 'Frontend\DiscussionController@unclose'
	]);
	Route::get('discussion/{exerciseSlug}/{discussionId}/hide', [
		'as' => 'user/discussion/hide',
		'uses' => 'Frontend\DiscussionController@hide'
	]);
	Route::get('discussion/{exerciseSlug}/{discussionId}/unhide', [
		'as' => 'user/discussion/unhide',
		'uses' => 'Frontend\DiscussionController@unhide'
	]);
});

Route::group(['middleware' => 'permission:do-discussion'], function() {
	Route::get('discussion/{exerciseSlug}', [
		'as' => 'user/discussion/index',
		'uses' => 'Frontend\DiscussionController@index'
	]);
	Route::get('discussion/{exerciseSlug}/create-new-discussion', [
		'as' => 'user/discussion/create',
		'uses' => 'Frontend\DiscussionController@create'
	]);
	Route::get('discussion/{exerciseSlug}/{discussionId}', [
		'as' => 'user/discussion/show',
		'uses' => 'Frontend\DiscussionController@show',
		'middleware' => 'discussion-hidden'
	]);
	Route::post('discussion/{exerciseSlug}', [
		'as' => 'user/discussion/store',
		'uses' => 'Frontend\DiscussionController@store'
	]);
	Route::post('discussion/{exerciseSlug}/{discussionId}', [
		'as' => 'user/discussion-post/store',
		'uses' => 'Frontend\DiscussionPostController@store',
		'middleware' => 'discussion-closed'
	]);
	Route::put('discussion/{exerciseSlug}/{discussionId}/{discussionPostId}', [
		'as' => 'user/discussion-post/update',
		'uses' => 'Frontend\DiscussionPostController@update',
		'middleware' => ['post-ownership', 'discussion-closed']
	]);
});


//Backend
Route::group(['prefix' => 'admin', 'middleware' => 'permission:access-backend'], function() {
   Route::get('/', [
   		'as' => 'admin/index',
   		'uses'	=> 'Backend\PageController@index'
   ]);

   Route::group(['prefix' => 'title'], function() {
		Route::get('/', [
			'as'	=> 'title/index',
			'uses'	=> 'Backend\TitleController@index'
		]);
		Route::get('/create', [
			'as'	=> 'title/create',
			'uses'	=> 'Backend\TitleController@create'
		]);
		Route::get('/{id}/edit', [
			'as'	=> 'title/edit',
			'uses'	=> 'Backend\TitleController@edit'
		]);
		Route::delete('/{id}', [
			'as'	=> 'title/destroy',
			'uses'	=> 'Backend\TitleController@destroy'
		]);
		Route::post('/', [
			'as'	=> 'title/store',
			'uses'	=> 'Backend\TitleController@store'
		]);
		Route::put('/{id}', [
			'as'	=> 'title/update',
			'uses'	=> 'Backend\TitleController@update'
		]);
   });

   Route::group(['prefix' => 'exercises'], function() {
      Route::get('/', [
        'as'  => 'exercise/index',
        'uses' => 'Backend\ExerciseController@index'
      ]);
      Route::get('/create', [
        'as'  => 'exercise/create',
        'uses' => 'Backend\ExerciseController@create'
      ]);
      Route::get('/{id}/edit', [
      	'as' => 'exercise/edit',
      	'uses' => 'Backend\ExerciseController@edit'
      ]);
      Route::put('/{id}', [
      	'as' => 'exercise/update',
      	'uses' => 'Backend\ExerciseController@update'
      ]);
      Route::post('/', [
        'as'  => 'exercise/store',
        'uses' => 'Backend\ExerciseController@store'
      ]);
      Route::delete('/{id}', [
      	'as' => 'exercise/destroy',
      	'uses' => 'Backend\ExerciseController@destroy'
      ]);
   });

   Route::group(['prefix' => 'courses'], function() {
      Route::get('/', [
        'as'  => 'course/index',
        'uses' => 'Backend\CourseController@index'
      ]);
      Route::get('/create', [
        'as'  => 'course/create',
        'uses' => 'Backend\CourseController@create'
      ]);
      Route::get('/{id}/edit', [
      	'as' => 'course/edit',
      	'uses' => 'Backend\CourseController@edit'
      ]);
      Route::put('/{id}', [
      	'as' => 'course/update',
      	'uses' => 'Backend\CourseController@update'
      ]);
      Route::post('/', [
        'as'  => 'course/store',
        'uses' => 'Backend\CourseController@store'
      ]);
      Route::delete('/{id}', [
      	'as' => 'course/destroy',
      	'uses' => 'Backend\CourseController@destroy'
      ]);
   });

   Route::group(['prefix' => 'achievements'], function() {
      Route::get('/', [
        'as'  => 'achievement/index',
        'uses' => 'Backend\AchievementController@index'
      ]);
      Route::get('/create', [
        'as'  => 'achievement/create',
        'uses' => 'Backend\AchievementController@create'
      ]);
      Route::get('/{id}/edit', [
      	'as' => 'achievement/edit',
      	'uses' => 'Backend\AchievementController@edit'
      ]);
      Route::put('/{id}', [
      	'as' => 'achievement/update',
      	'uses' => 'Backend\AchievementController@update'
      ]);
      Route::post('/', [
        'as'  => 'achievement/store',
        'uses' => 'Backend\AchievementController@store'
      ]);
      Route::delete('/{id}', [
      	'as' => 'achievement/destroy',
      	'uses' => 'Backend\AchievementController@destroy'
      ]);
   });
});

