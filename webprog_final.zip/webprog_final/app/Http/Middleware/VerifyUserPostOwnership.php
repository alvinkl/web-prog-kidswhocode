<?php

namespace App\Http\Middleware;

use Closure;

use App\DiscussionPost;

class VerifyUserPostOwnership
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $discussionPost = DiscussionPost::findOrFail($request->discussionPostId);

        if($discussionPost->user_id != auth()->user()->id)
            abort(403);

        return $next($request);
    }
}
