<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Typing game</title>
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.3/animate.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<style>
   * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
}

body {
  background-color: #ecf0f1;
  font-family: 'Raleway', sans-serif;
}

.wrapper {
  max-width: 600px;
  margin: 0 auto;
  width: 100%;
  text-align: center;
  padding: 2%;
  background-color: #34495e;
  height: 500px;
}

h1 {
    color: #ecf0f1;
}

h1 + p {
  margin-bottom: 5%;
    color: #3498db;
}

.scoreWrap {float: left;}
.timeWrap {float: right;}

.outerWrap:after {
  content: "";
  display: block;
  clear: both;
}

.bg {
  background-color: #04AF71;
}

button {
    border: none;
    background-color: #2ecc71;
    box-shadow: 0px 5px 0px 0px #27ae60;
    outline: none;
    border-radius: 5px;
    padding: 10px 15px;
    font-size: 22px;
    text-decoration: none;
    margin: 20px;
    color: #fff;
    position: relative;
    display: inline-block;
    cursor: pointer;
}

.next {
    background-color: #3498db;
    box-shadow: 0 5px 0 0 #2980b9;
    display: none;
}

#restart {
    background-color: #e74c3c;
    box-shadow: 0 5px 0 0 #c0392b;
    display: none;
}

button:active {
    transform: translate(0px, 5px);
    -webkit-transform: translate(0px, 5px);
    box-shadow: 0px 1px 0px 0px;
}

.scoreWrap p, .scoreWrap span, .timeWrap p, .timeWrap span {
    font-size: 30px;
    color: #FF7373;
}

.wordsWrap {
  margin-top: 50px;
}

.words {
    color: #ECF0F1;
}

.words span{
    font-size: 60px;
    letter-spacing: 1px;
    color: #ECF0F1;
}

.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px;
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}
 
  </style>
</head>
<body>
	<div class="wrapper">
		<h1>Typing game < Smarter Code ></h1>
		<button id='start'>START</button>
        <button class='next'>NEXT</button>
		<div class="outerWrap">
			<div class="scoreWrap">
				<p>Score</p>
				<span class="score">0</span>
			</div>
			<div class="timeWrap">
				<p>Time left</p>
				<span class="time">60</span>
			</div>
		</div>
		<div class="wordsWrap">
			<p class="words"></p>
		</div>
	</div>

    <div class="container">
      <!-- Modal -->
      <div class="modal fade" id="modal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Great Job!</h4>
            </div>
            <div class="modal-body">
              <div id='modaltxt'></div>
              <div id='total'>Total Point : </div>
            </div>
            <div class="modal-footer">
              <button class='next'>NEXT</button>
              <button id='restart'>RESTART</button>
            </div>
          </div>

        </div>
      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src=' <?php echo e(asset("js/typing-script.js")); ?>'></script>
</body>
