<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Title</div>

                <div class="panel-body">
                    <form action="<?php echo e(route('title/store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Title name here...">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="level" class="form-label">Level</label>
                            <input type="number" name="level" class="form-control" min="0" value="0">
                            <?php if($errors->has('level')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('level')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Create</button>
                            <a href="<?php echo e(route('title/index')); ?>" class="btn btn-default right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>