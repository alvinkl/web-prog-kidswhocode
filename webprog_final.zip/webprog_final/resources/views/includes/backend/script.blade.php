<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>
<!-- <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script> -->
<!-- <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script> -->
<script src="{{asset('js/datatables/datatables.min.js')}}"></script>
<script>
	//Script for preloader
	window.addEventListener('load', function() {
		$('#overlay').fadeOut(1000);
	});

	$(document).ready(function() {
		if($('#flash-message').length != 0) {
			console.log('message!');
			$('#flash-message').fadeIn(1000);
			setTimeout(function() {
				$('#flash-message').fadeOut(1000);
			}, 5000);
		}
	});
</script>