<?php

namespace App\Listeners;

use App\Events\ExerciseCompleted;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

use App\Achievement;
use App\Helpers\Flash;

class CheckForExerciseAchievement
{

    public $user;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        $this->user = auth()->user();
    }

    /**
     * Handle the event.
     *
     * @param  ExerciseCompleted  $event
     * @return void
     */
    public function handle(ExerciseCompleted $event)
    {
        $exerciseCount = $this->user->exerciseCount();
        $achievement = null;

        switch($exerciseCount) {
            case 1 :
                $achievement = Achievement::where('name', '1 Exercise')->first();
                break;
            case 3 :
                $achievement = Achievement::where('name', '3 Exercise')->first();
                break;
            case 5 :
                $achievement = Achievement::where('name', '5 Exercise')->first();
                break;
        }

        if($achievement && !$this->user->hasAchievement($achievement->id)) {
            $this->user->achievements()->attach($achievement);
            Flash::message('success', 'Anda mendapatkan pencapaian "'. $achievement->name .'"!');
        }
    }
}
