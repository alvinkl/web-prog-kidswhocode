@extends('layouts.master-backend')

@section('additional-style')
<style>
    #iframe-editor,
    #default-editor {
        width: 100%;
        height: 200px;
    }
</style>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Exercise - Create</div>

                <div class="panel-body">
                    <form action="{{route('exercise/store')}}" method="POST" id="exercise-form">
                        {{csrf_field()}}

                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Exercise name here..." value="{{old('name')}}">
                            @if ($errors->has('name'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="slug" class="form-label">Slug</label>
                            <input type="text" name="slug" class="form-control" placeholder="Exercise Slug here..." value="{{old('slug')}}">
                            @if ($errors->has('slug'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('slug') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="ordering" class="form-label">Ordering</label>
                            <input type="number" name="ordering" min="1" class="form-control" value="{{old('ordering') == null ? 1 : old('ordering')}}">
                            @if ($errors->has('ordering'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('ordering') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="course_id" class="form-label">Course</label>
                            <select name="course_id" class="form-control">
                                @foreach($courses as $course)
                                    <option value="{{$course->id}}">{{$course->name}}</option>
                                @endforeach
                            </select>
                            @if ($errors->has('course_id'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('course_id') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="10" placeholder="Enter the description here...">{{old('description')}}</textarea>
                            @if ($errors->has('description'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('description') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="default_code" class="form-label">Default Code</label>
                            <div id="default-editor">
                                
                            </div>
                            <input type="hidden" id="default-code" name="default_code">
                            @if ($errors->has('default_code'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('default_code') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="iframe_file" class="form-label">IFrame File (For validating code)</label>
                            <div id="iframe-editor">
                                
                            </div>
                            <input type="hidden" id="iframe-file" name="iframe_file">
                            @if ($errors->has('iframe_file'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('iframe_file') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="experience_point" class="form-label">Experience Point</label>
                            <input type="number" name="experience_point" class="form-control" min="50" value="{{old('experience_point') === null ? 50 : old('experience_point')}}" step="50">
                            @if ($errors->has('experience_point'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('experience_point') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Create</button>
                            <a href="{{route('exercise/index')}}" class="btn btn-default right">Back</a>
                        </div>
                        <textarea id="template-iframe-code" hidden>{!! old('iframe_file') != null ? old('iframe_file') : $templateIframeCode !!}</textarea>
                        <textarea id="template-default-code" hidden>{!! old('default_code') != null ? old('default_code') : $templateDefaultCode !!}</textarea>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('additional-script')
<script src="{{asset('js/ace/ace.js')}}"></script>
<script src="{{asset('js/ace/theme-monokai.js')}}"></script>
<script src="{{asset('js/ace/mode-html.js')}}"></script>
<script src="{{asset('js/ace/worker-html.js')}}"></script>
<script>
    $(document).ready(function(e) {
        var iframeEditor = ace.edit('iframe-editor');
        var defaultEditor = ace.edit('default-editor');
        var hiddenIframeCode = $("#template-iframe-code").val();
        var hiddenDefaultCode = $("#template-default-code").val();

        $("#template-iframe-code").empty();
        $("#template-default-code").empty();

        iframeEditor.setValue(hiddenIframeCode);
        defaultEditor.setValue(hiddenDefaultCode);
        

        iframeEditor.setTheme("ace/theme/monokai");
        iframeEditor.getSession().setMode("ace/mode/html");
        iframeEditor.getSession().setUseWorker(false);

        defaultEditor.setTheme("ace/theme/monokai");
        defaultEditor.getSession().setMode("ace/mode/html");
        defaultEditor.getSession().setUseWorker(false);

        $("#exercise-form").submit(function(e) {
            moveCode(iframeEditor, 'iframe-file');
            moveCode(defaultEditor, 'default-code');
        });

    });

    function moveCode(from, to) {
        //from is ace code instance
        //to is HTML id
        var code = from.getValue();
        $("#" + to).val(code);
    }
  
</script>
@endsection