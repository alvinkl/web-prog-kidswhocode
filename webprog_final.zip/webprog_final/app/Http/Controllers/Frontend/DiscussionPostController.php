<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\DiscussionPostCreationRequest;
use App\Http\Requests\DiscussionPostUpdateRequest;

use App\Exercise;
use App\Discussion;
use App\DiscussionPost;


class DiscussionPostController extends Controller
{
    public function store(DiscussionPostCreationRequest $request, $exerciseSlug, $discussionId) {

    	$user = auth()->user();

    	$discussionPost = DiscussionPost::create([
    		'discussion_id' => $discussionId,
    		'user_id' => $user->id,
    		'content' => $request->content
    	]);

    	return redirect()->route('user/discussion/show', ['exerciseSlug' => $exerciseSlug, 'discussionId' => $discussionId]);
    }

    public function update(DiscussionPostUpdateRequest $request, $exerciseSlug, $discussionId, $discussionPostId) {

        $discussionPost = DiscussionPost::find($discussionPostId);

        $discussionPost->content = $request->content;
        $discussionPost->save();

        return redirect()->route('user/discussion/show', ['exerciseSlug' => $exerciseSlug, 'discussionId' => $discussionId]);
    }
}
