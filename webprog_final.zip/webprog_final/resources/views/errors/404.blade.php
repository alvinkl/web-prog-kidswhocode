@extends('layouts.master-frontend')

@section('content')
    <div class="container">
        <div class="content">
            Page Not Found, <a href="{{ route('index') }}">Click here</a> to go to index
        </div>
    </div>
@endsection

