<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><a href="<?php echo e(route('user/course', $exercise->course->slug)); ?>"><?php echo e($exercise->course->name); ?></a> - <a href="<?php echo e(route('user/exercise/show', $exercise->slug)); ?>"><?php echo e($exercise->name); ?></a> - Discussions - <a href="<?php echo e(route('user/discussion/create', $exercise->slug)); ?>" class="btn btn-default">Create a New Discussion</a></div>

                <div class="panel-body">
                    <?php if($discussions->count() == 0): ?>
                        <h3 class="text-center">Belum ada yang berdiskusi untuk tutorial ini...</h3>
                    <?php endif; ?>
                	<!-- Gambaran aja nanti kayak gini tampilannya -->
                    <?php $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <ul class="list-group">
                            
                                <li class="list-group-item">
                                    <a href="<?php echo e(route('user/discussion/show', ['exerciseSlug' => $exercise->slug, 'discussionId' => $discussion->id])); ?>">
                                        <h3><?php echo e($discussion->title); ?></h3><br/>
                                    </a>
                                    <div style="text-align: right;">
                                        <?php if(auth()->user()->can('manage-discussion')): ?>
                                            <?php if($discussion->is_deleted): ?>
                                                <a href="<?php echo e(route('user/discussion/unhide', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-eye-open"></i> Unhide</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('user/discussion/hide', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-eye-close"></i> Hide</a>
                                            <?php endif; ?>
                                            -
                                            <?php if($discussion->is_closed): ?>
                                                <a href="<?php echo e(route('user/discussion/unclose', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-ok"></i> Unclose</a>
                                            <?php else: ?>
                                               <a href="<?php echo e(route('user/discussion/close', [$exercise->slug, $discussion->id])); ?>" class="btn btn-default"><i class="glyphicon glyphicon-remove"></i> Close</a>
                                            <?php endif; ?>
                                            -
                                        <?php endif; ?>
                                        <em >oleh <?php echo e($discussion->starter->username); ?>, pada tanggal <?php echo e($discussion->created_at->format('d-m-Y, H:i:s')); ?></em>
                                    </div>
                                </li>
                        </ul>
                        <?php echo e($discussions->links()); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>