<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Discussions - <a href="<?php echo e(route('user/discussion/index', $exercise->slug)); ?>"><?php echo e($exercise->name); ?></a> - Create new Discussion</a></div>

                <div class="panel-body">
                	<!-- Gambaran aja nanti kayak gini tampilannya -->
                    <form action="<?php echo e(route('user/discussion/store', $exercise->slug)); ?>" method="POST">
                    
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                            <label for="title" class="form-label">Judul</label>
                            <input type="text" name="title" class="form-control" placeholder="Masukkan judul disini..." value="<?php echo e(old('title')); ?>">
                            <?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
                            <label for="content" class="form-label">Isi</label>
                            <textarea class="form-control" name="content" placeholder="Masukkan isi disini..."><?php echo e(old('content')); ?></textarea>
                            <?php if($errors->has('content')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('content')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group" class="text-center">
                            <?php echo captcha_img(); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('captcha') ? 'has-error' : ''); ?>" id="group-captcha">
                            <label for="captcha">Captcha : </label>
                            <input type="text" name="captcha" id="captcha" placeholder="Masukkan captcha disini" value="<?php echo e(old('captcha')); ?>" class="form-control"/>
                            <p class="help-block"><?php echo e($errors->first('captcha')); ?></p>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Create</button>
                            <a href="<?php echo e(route('user/discussion/index', $exercise->slug)); ?>" class="btn btn-default right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>