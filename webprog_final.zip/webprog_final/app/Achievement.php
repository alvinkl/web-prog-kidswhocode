<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'image', 'description'
    ];

    /**
     * Users which have this achievement
     */
    public function users() {
        return $this->belongsToMany(\App\User::class, 'achievement_user', 'achievement_id', 'user_id');
    }
}
