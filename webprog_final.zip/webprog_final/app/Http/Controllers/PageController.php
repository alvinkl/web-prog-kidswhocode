<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

use App\Http\Requests;
use App\ContactMessage;
use App\Http\Requests\ContactFormRequest;
use App\Mail\ContactFormSubmitted;

use App\Helpers\Flash;

use App\TypingText;
use App\User;

class PageController extends Controller
{
    public function index() {

    	return view('frontend.index');
    	
    }

    public function showContactForm() {

        $user = auth()->user();
    	return view('frontend.contact', compact('user'));

    }

    public function contact(ContactFormRequest $request) {

    	$contactMessage = new ContactMessage();

    	$contactMessage->name = $request->name;
    	$contactMessage->email = $request->email;
    	$contactMessage->message = $request->message;
    	$contactMessage->save();

        Mail::send(new ContactFormSubmitted($contactMessage));

    	if(count(Mail::failures()) == 0)
            Flash::message('success', 'Pesan berhasil dikirim, terima kasih atas pesan anda');
        else
            Flash::message('danger', 'Mohon maaf, pesan gagal dikirim. Silahkan hubungi admin kami');

    	return redirect()->back()->with('success', 'Thanks for contact us, we will reply soon');

    }

    public function test() {
        return view('coding_test.index');
    }

    public function typing() {
        return view('coding_test.typing');
    }

    public function getWords() {
        $text = TypingText::inRandomOrder()->first()->content;

        return $text;
    }

    public function updateScore(Request $request) {

        $user = User::find($request->userid);
        return response()->json([
            'greater' => $user->isGreaterScore($request->score)
        ]);
            

    }
}
