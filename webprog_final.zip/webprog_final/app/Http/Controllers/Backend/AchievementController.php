<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Intervention\Image\Facades\Image;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Achievement;

use App\Http\Requests\AchievementCreationRequest;
use App\Http\Requests\AchievementUpdateRequest;

class AchievementController extends Controller
{
    public function index() {

        $achievements = Achievement::all();

    	return view('backend.achievements.index', compact([
            'achievements'
        ]));
    }

    public function create() {

        return view('backend.achievements.create');

    }

    public function edit($id) {

        $achievement = Achievement::findOrFail($id);

        return view('backend.achievements.edit', compact([
            'achievement'
        ]));

    }

    public function update(AchievementUpdateRequest $request, $id) {

        $achievement = Achievement::findOrFail($id);

        if(Input::file('image')) {
            $image = Input::file('image');
            $filename = date('dmyHis') . '.' . $image->getClientOriginalExtension();
            $destination = public_path('image/achievement/' . $filename);

            //Delete unused old image
            if(File::exists(public_path('image/achievement/' . $achievement->image))) 
                File::delete(public_path('image/achievement/' . $achievement->image));

            //Creating resized image
            Image::make($image->getRealPath())->resize(64, 64)->save($destination);

            //Change image
            $achievement->image = $filename;
        }

        $achievement->name = $request->name;
        $achievement->description = $request->description;
        $achievement->save();

        return redirect()->route('achievement/index');
    }

    public function destroy($id) {

        $achievement = Achievement::findOrFail($id);     

        //Delete unused old image
        if(File::exists(public_path('image/achievement/' . $achievement->image))) 
            File::delete(public_path('image/achievement/' . $achievement->image));

        $achievement->delete();

        return redirect()->route('achievement/index');
    }

    public function store(AchievementCreationRequest $request) {

    	$image = Input::file('image');
        $filename = date('dmyHis') . '.' . $image->getClientOriginalExtension();
        $destination = public_path('image/achievement/' . $filename);

        //Creating resized image
        Image::make($image->getRealPath())->resize(64, 64)->save($destination);

    	Achievement::create([
    		'name' => $request->name,
    		'image' => $filename,
    		'description' => $request->description
    	]);

    	return redirect()->route('achievement/index');

    }
}
