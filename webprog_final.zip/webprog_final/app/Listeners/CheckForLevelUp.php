<?php

namespace App\Listeners;

use App\Events\ExerciseCompleted;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

use App\Helpers\Flash;

class CheckForLevelUp
{
    /**
     * Handle the event.
     *
     * @param  ExerciseCompleted  $event
     * @return void
     */
    public function handle(ExerciseCompleted $event)
    {
        $user = auth()->user();

        /**
         * Checking for level up, next level exp is double of the current level exp
         */

        while($user->experience_point >= $user->nextLevelExp()){
            $user->levelUp();
            Flash::message('success', 'Anda baru saja naik ke level ' . $user->level . '!');
        }
    }
}
