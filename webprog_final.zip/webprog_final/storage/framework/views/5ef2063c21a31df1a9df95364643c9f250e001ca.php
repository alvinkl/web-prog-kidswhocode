<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content">
            Page Not Found, <a href="<?php echo e(route('index')); ?>">Click here</a> to go to index
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>