<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Course;
use App\CourseTopic;
use App\Exercise;
use App\Discussion;

class CourseController extends Controller
{
    public function index() {
    	$courseTopics = CourseTopic::with('courses')->get();

        if(auth()->user()->can('manage-discussion'))
            $latestDiscussions = Discussion::with('exercise')->orderBy('updated_at', 'desc')->take(5)->get();
        else
            $latestDiscussions = Discussion::with('exercise')->where('is_deleted', false)->orderBy('updated_at', 'desc')->take(5)->get();

    	return view('frontend.course-index', compact([
            'courseTopics',
            'latestDiscussions'
    	]));
    }

    public function show($courseSlug) {

    	$course = Course::with('exercises')->where('slug', $courseSlug)->first();

        if(auth()->user()->can('manage-discussion'))
            $latestDiscussions = \DB::table('discussions')
                    ->join('exercises', 'discussions.exercise_id', '=', 'exercises.id')
                    ->join('courses', 'exercises.course_id', 'courses.id')
                    ->join('users', 'discussions.user_id', 'users.id')
                    ->where('courses.id', $course->id)
                    ->select('exercises.name as exercise_name', 'discussions.id as discussion_id', 'discussions.title as discussion_title', 'discussions.created_at as created_at', 'exercises.slug as exercise_slug', 'users.username as username', 'discussions.title as title', 'discussions.is_deleted as is_deleted', 'discussions.is_closed as is_closed')
                    ->orderBy('discussions.updated_at', 'desc')
                    ->take(5)
                    ->get();
        else
            $latestDiscussions = \DB::table('discussions')
                    ->join('exercises', 'discussions.exercise_id', '=', 'exercises.id')
                    ->join('courses', 'exercises.course_id', 'courses.id')
                    ->join('users', 'discussions.user_id', 'users.id')
                    ->where('courses.id', $course->id)
                    ->where('discussions.is_deleted', false)
                    ->select('exercises.name as exercise_name', 'discussions.id as discussion_id', 'discussions.title as discussion_title', 'discussions.created_at as created_at', 'exercises.slug as exercise_slug', 'users.username as username', 'discussions.title as title', 'discussions.is_deleted as is_deleted', 'discussions.is_closed as is_closed')
                    ->orderBy('discussions.updated_at', 'desc')
                    ->take(5)
                    ->get();

    	$exercises = $course->exercises->sortBy('ordering');

    	return view('frontend.course-detail', compact([
            'course',
            'latestDiscussions',
            'exercises'
        ]));
    }
}
