<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('includes.frontend.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('additional-includes'); ?>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Proyek Web Programming')); ?></title>

    <!-- Scripts, CSRF protection -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

     <!-- Additional style -->
    <?php echo $__env->yieldContent('additional-style'); ?>
</head>
<body>
    <!-- Navigation Bar -->
    <?php echo $__env->make('includes.frontend.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer -->
    <?php echo $__env->make('includes.frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Scripts -->
    <?php echo $__env->make('includes.frontend.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Additional script -->
    <?php echo $__env->yieldContent('additional-script'); ?>
</body>
</html>
