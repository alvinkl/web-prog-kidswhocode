<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"> </script>
<script src="<?php echo e(asset('js/index.js')); ?>" charset="utf-8"></script>
<script>
	$('#web-content').hide(0);

	//Untuk memunculkan preloader
	window.addEventListener('load', function() {
		$('#overlay').fadeOut(500);
		$('#web-content').fadeIn(500);
	});

	window.addEventListener('unload', function() {
		$('#overlay').show(0);
		$('#web-content').hide(0);
	});

	//Untuk flash message, fadein dan fadeout
	$(document).ready(function() {
		if($('#flash-message').length != 0) {
			$('#flash-message').fadeIn(1000);
			setTimeout(function() {
				$('#flash-message').fadeOut(1000);
			}, 3000);
		}
	});

</script>