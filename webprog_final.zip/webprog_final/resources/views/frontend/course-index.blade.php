@extends('layouts.master-frontend')

@section('content')
<div class="container">
    <ul class="nav nav-tabs md-pills pills-default" role="tablist">
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#excercise" role="tab"><i class="fa fa-graduation-cap fa-2x"></i> Courses</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#discussion" role="tab"><i class="fa fa-users fa-2x"></i> Diskusi Terbaru</a>
        </li>
    </ul>

    <div class="tab-content">
          <div class="tab-pane fade in active" id="excercise" role="tabpanel">
             @foreach($courseTopics as $courseTopic)
            <div class="panel-body">
              <div class="media">
                <div class="media-left media-middle">
                  <a href="#">
                    <img class="media-object media-img d-flex mr-3" src="{{ asset('image/' . $courseTopic->name . '.png') }}" alt="html5" style="height: 128px;width: 128px;">

                    <!-- Imagenya download, taro di public/image, terus kasih nama html.png sama css.png aja, biar nanti klo mo load image langsung berdasarkan nama courseya (inget case sensitve-->
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading">{{$courseTopic->name}}</h4>
                  
                    <hr>
                    <ul class="list-group">
                        @foreach($courseTopic->courses as $course)
                            <a href="{{route('user/course', $course->slug)}}">
                                <li class="list-group-item">
                                    <img style="width: 25px; height: 25px;" src="{{ asset('image/' . $course->slug . '.png') }}"> {{ $course->name }}
                                </li>
                            </a>
                        @endforeach
                    </ul>
                </div>
              </div>
            </div>
            @endforeach
            </div>
            
          <div class="tab-pane fade" id="discussion" role="tabpanel">
            <div class="panel-body">
              @if($latestDiscussions->count() == 0)
                    <h3 class="text-center">Belum ada yang berdiskusi saat ini...</h3>
                @endif

                <!-- Gambaran aja nanti kayak gini tampilannya -->
                @foreach($latestDiscussions as $discussion)
                    <ul class="list-group">
                        <a href="{{route('user/discussion/show', ['exerciseSlug' => $discussion->exercise->slug, 'discussionId' => $discussion->id])}}">
                            <li class="list-group-item">
                                <span>{{$discussion->exercise->course->name}} - </span>                                    
                                <span>{{ $discussion->title }}  {{ $discussion->is_deleted ? '- hidden' : ''}} {{ $discussion->is_closed ? '- closed' : ''}}</span>
                                <em style="text-align: right; float: right; color: black;">{{ $discussion->starter->username}}, {{ $discussion->created_at->format('d-m-Y, H:i:s') }}</em>
                            </li>
                        </a>
                    </ul>
                @endforeach
            </div>
          </div>
      </div>
</div>
@endsection
