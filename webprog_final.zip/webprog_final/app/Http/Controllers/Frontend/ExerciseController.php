<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Exercise;

use App\Helpers\Flash;
use App\Events\ExerciseCompleted;

class ExerciseController extends Controller
{
    public function show($exerciseSlug) {
    	$exercise = Exercise::with('course')->where('slug', $exerciseSlug)->first();
    	$user = auth()->user();
    	$course = $exercise->course;
        $user_code = null;

    	if($exercise->users->contains($user->id))
    		$user_code = $exercise->users()->where('user_id', $user->id)->first()->pivot->user_code;

    	return view('frontend.exercise', compact([
    		'exercise',
    		'course',
    		'user_code'
    	]));
    }

    public function store(Request $request, $exerciseSlug) {

    	$user = auth()->user();
		$exercise = Exercise::with('course')->where('slug', $exerciseSlug)->first();
		$alreadyDone = $exercise->users->contains($user->id);

    	if($alreadyDone) {
    		$exercise->users()->detach($user);
	    	$exercise->users()->attach($user, ['user_code' => $request->user_code]);
    	}	
    	else {
	    	$exercise->users()->attach($user, ['user_code' => $request->user_code]);
	    	$user->experience_point += $exercise->experience_point;
	    	$user->save();
            Flash::message('success', 'Anda baru saja mendapatkan exp ' . $exercise->experience_point . ' point!');
    	}

    	$nextExercise = Exercise::with('course')->where('ordering', '>', $exercise->ordering)
                                                ->where('course_id', $exercise->course_id)
                                                ->orderBy('ordering', 'asc')->first();

        //Firing exercise completed event
        event(new ExerciseCompleted($exercise));

    	if($nextExercise == null)
    		return redirect()->route('user/course', $exercise->course()->first()->slug);
    	else
    		return redirect()->route('user/exercise/show', $nextExercise->slug);
    }
}
