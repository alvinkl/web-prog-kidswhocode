<?php $__env->startSection('additional-style'); ?>
    <style>
        #preview {
            height: 400px;
            width: 100%;
            border: solid 1px #C8C8C8;
        }

        #description {
            height: 300px;
            width: 100%;
            overflow: scroll;
        }

        #editor {
            width: 100%;
            height: 150px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($course->name); ?> - Exercise - <?php echo e($exercise->name); ?></div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <h3><?php echo e($exercise->name); ?></h3>
                            <hr>
                            <div id="description">
                                <?php echo nl2br($exercise->description); ?>

                            </div>
                        </div>
                        <div class="col-md-8">
                            <iframe id="preview" frameborder="0" src="<?php echo e(asset('html/' . $exercise->iframe_file)); ?>"></iframe>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <div id="editor"></div>
                            <hr>
                            <form action="<?php echo e(route('user/exercise/store', $exercise->slug)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" id="user-code" name="user_code">
                                <button id="btn-next" class='btn btn-default' type='submit' disabled>Next</button>    
                            </form>
                            <div class="pull-right">
                                <a href="<?php echo e(route('user/course', $course->slug)); ?>">Back to the exercise list</a>
                            </div> 
                        </div>
                    </div>
                </div>

                <template id="hidden-default-code"><?php echo $user_code == null ? $exercise->default_code : $user_code; ?></template>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-script'); ?>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ace/ace.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ace/theme-monokai.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ace/mode-html.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ace/worker-html.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            //setting text editor
            var editor = ace.edit("editor");
            editor.resize();
            editor.setTheme("ace/theme/monokai");
            editor.getSession().setMode("ace/mode/html");
            editor.getSession().setUseWrapMode(true);
            editor.getSession().setUseWorker(false);

            //setting preview
            var preview = document.getElementById('preview');

            //setting default code
            var hiddenDefaultCode = document.getElementById('hidden-default-code');
            
            //setting initial value
            var frameDoc = preview.contentDocument || preview.contentWindow.document;

            editor.setValue(hiddenDefaultCode.innerHTML);
            frameDoc.getElementById('user-html').innerHTML = editor.getValue();
            hiddenDefaultCode.innerHTML = "";

             $(window).keydown(function(e) {
              if (e.ctrlKey && e.keyCode == 13) {
                var frameDoc = preview.contentDocument || preview.contentWindow.document;
                var buttonNext = document.getElementById('btn-next');
                editorContent = editor.getValue();

                frameDoc.getElementById("user-html").innerHTML = editorContent;
                localStorage.code = editorContent;

                if (frameDoc.getElementById('error-msg').innerHTML === 'benar') {
                    setTimeout(() => buttonNext.className = 'btn btn-primary', 10);
                    buttonNext.disabled = false;
                    moveCode(editor, 'user-code');
                }
                else {
                    setTimeout(() => buttonNext.className = 'btn btn-default', 10);
                    buttonNext.disabled = true;
                }
              }
            })
        }); 

        function moveCode(from, to) {
            //from is ace code instance
            //to is HTML id
            var code = from.getValue();
            $("#" + to).val(code);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>