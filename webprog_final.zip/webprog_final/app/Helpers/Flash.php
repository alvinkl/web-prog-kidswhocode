<?php

namespace App\Helpers;

class Flash {

	public static function message($type, $message) {

	    session()->flash('flash_type', $type);
		session()->flash('flash_message', $message);

	}
}

