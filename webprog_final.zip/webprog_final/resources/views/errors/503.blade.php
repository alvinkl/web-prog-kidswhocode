@extends('layouts.master-frontend')

@section('content')
    <div class="container">
        <div class="content">
            <div class="title">Be right back.</div>
        </div>
    </div>
@endsection

