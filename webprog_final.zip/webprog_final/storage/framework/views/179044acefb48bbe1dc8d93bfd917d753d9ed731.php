<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="buffer">
  <div class="row-fluid">
    <div class="col-xs-12 col-sm-8">
      <img src="./image/1.png" alt="">
    </div>
    <div class="col-xs-12 col-sm-4">
      <form class='text-center' role="form" method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo e(csrf_field()); ?>

        <h3>Login</h3>
        <hr>
          <div class="form-group" class="form-group" class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
            <input type="text" id="username" name="username" class="form-control text-center" placeholder="Username" value="<?php echo e(old('username')); ?>" required autofocus>
            <?php if($errors->has('username')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('username')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group" class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <input type="password" class="form-control text-center" placeholder="Password" id="password" name="password" required>
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div>
            <label>
              <input type="checkbox"> Remember me
            </label>
          </div>
          <button type="submit" class="btn btn-login">Login</button>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>