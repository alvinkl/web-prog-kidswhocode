@extends('layouts.master-backend')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Title</div>

                <div class="panel-body">
                    <table id="title-table" class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Level</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($titles as $title)
                                <tr>
                                    <td>{{$title->id}}</td>
                                    <td>{{$title->name}}</td>
                                    <td>{{$title->level}}</td>
                                    <td><a href="{{route('title/edit', $title->id)}}" class="btn btn-default">Update</a></td>
                                    <td>
                                        <form action="{{route('title/destroy', $title->id)}}" method="POST">
                                            {{ csrf_field() }}
                                            {{ method_field('DELETE') }}
                                            <button type="submit" class="btn btn-default">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="panel-footer">
                    <a class="btn btn-default" href="{{route('title/create')}}">Create new Title</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('additional-script')
    <script>
        $(document).ready(function() {
            $('#title-table').DataTable();
        });          
    </script>
@endsection