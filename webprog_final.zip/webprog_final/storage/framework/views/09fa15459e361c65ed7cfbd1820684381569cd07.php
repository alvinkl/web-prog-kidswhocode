<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Achievement - Edit</div>

                <div class="panel-body">
                    <form action="<?php echo e(route('achievement/update', $achievement->id)); ?>" method="POST" id="achievement-form" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>


                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Achievement name here..." value="<?php echo e(old('name') == null ? $achievement->name : old('name')); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" name="image" class="form-control" placeholder="Achievement image here...">
                            <?php if($errors->has('image')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="10" placeholder="Enter the description here..."><?php echo e(old('description') == null ? $achievement->description : old('description')); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Edit</button>
                            <a href="<?php echo e(route('achievement/index')); ?>" class="btn btn-default right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>