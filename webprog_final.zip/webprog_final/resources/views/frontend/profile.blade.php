@extends('layouts.master-frontend')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Profile - {{ $user->username }}</div>

                <div class="panel-body">
                	<table class="table">
                        <tbody>
                            <tr>
                                <td>Username</td>
                                <td>{{ $user->username }}</td>
                            </tr>
                            <tr>
                                <td>Nama</td>
                                <td>{{ $user->name }}</td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>{{ $user->email }}</td>
                            </tr>
                            <tr>
                                <td>Level</td>
                                <td>{{ $user->level }} ({{ $user->title->name }})</td>
                            </tr>
                            <tr>
                                <td>Exp</td>
                                <td>{{ $user->experience_point }} / {{ $user->nextLevelExp() }}</td>
                            </tr>
                        </tbody>
                      </table>
                </div>

                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-12">
                            <h4>Progress Level</h4>
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="{{ ($user->experience_point / $user->nextLevelExp() * 100) }}" aria-valuemin="0" aria-valuemax="100" style="width:{{ ($user->experience_point / $user->nextLevelExp() * 100) }}%">
                                {{ number_format((float)($user->experience_point / $user->nextLevelExp() * 100), 2, '.', '') }} %
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">Pencapaian</div>
                    
                <div class="panel-body">
                    <div class="row">
                        @foreach($achievements as $achievement)
                            <div class="col-md-4">
                                <div class="thumbnail" >
                                    <img src="{{ asset('image/achievement/' . $achievement->image) }}" class="img-responsive">
                                    <div class="caption">
                                        <h4 class="text-center"><label>{{$achievement->name}}</label></h4>
                                        <p class="text-center">{{ $achievement->description }}</p>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
