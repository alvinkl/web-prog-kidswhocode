
<nav role="navigation" class="navbar navbar">
  <div class="navbar-header ov-buff">
    <a  href="<?php echo e(route('index')); ?>" class="navbar-brand"><div id='brand' style="background-image: url('<?php echo e(asset('image/brand.png')); ?>');"></div></a>
  </div>
  <div id="navbarCollapse" class="collapse navbar-collapse">
    <ul class="nav navbar-nav navbar-right">
        <?php if(Auth::guest()): ?>
            <li><a href="<?php echo e(route('register/get')); ?>" id='signup'>Signup</a></li>
            <li><a href="<?php echo e(route('login/get')); ?>" id='login'>Login</a></li>
        <?php else: ?>

        <?php if($user->can('access-backend')): ?>
                <li><a href="<?php echo e(route('admin/index')); ?>">Go To Admin Panel</a></li>
            <?php endif; ?>
            
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <?php echo e($user->username); ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu" role="menu">
                    <li><a href="<?php echo e(route('user/index')); ?>">Profile</a></li>
                    <li>
                        <a href="<?php echo e(route('logout/post')); ?>"
                            onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout/post')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
  </div>
</nav>