@extends('layouts.master-frontend')
<link rel="stylesheet" href="{{asset('css/login.css')}}">

@section('content')
<div class="buffer">
  <div class="row-fluid">
    <div class="col-xs-12 col-sm-8">
      <img src="./image/1.png" alt="">
    </div>
    <div class="col-xs-12 col-sm-4">
      <form class='text-center' role="form" method="POST" action="{{ url('/login') }}">
        {{ csrf_field() }}
        <h3>Login</h3>
        <hr>
          <div class="form-group" class="form-group" class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
            <input type="text" id="username" name="username" class="form-control text-center" placeholder="Username" value="{{ old('username') }}" required autofocus>
            @if ($errors->has('username'))
                <span class="help-block">
                    <strong>{{ $errors->first('username') }}</strong>
                </span>
            @endif
          </div>

          <div class="form-group" class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
            <input type="password" class="form-control text-center" placeholder="Password" id="password" name="password" required>
            @if ($errors->has('password'))
                <span class="help-block">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
            @endif
          </div>

          <div>
            <label>
              <input type="checkbox"> Remember me
            </label>
          </div>
          <button type="submit" class="btn btn-login">Login</button>
      </form>
    </div>
  </div>
</div>
@endsection
