<?php

namespace App\Listeners;

use App\Events\ExerciseCompleted;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

use App\Achievement;
use App\Helpers\Flash;

class CheckForCourseCompletion
{

    public $user;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
         $this->user = auth()->user();
    }

    /**
     * Handle the event.
     *
     * @param  ExerciseCompleted  $event
     * @return void
     */
    public function handle(ExerciseCompleted $event)
    {
        $course = $event->exercise->course;

        if($course->isCompleted($this->user)) {
            $this->user->achievements()->attach(\App\Achievement::where('name', $course->name)->first());
            Flash::message('success', 'Anda baru saja menyelesaikan course ' . $course->name . '!');    
        }
    }
}
