<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
	 /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

	/**
	 * Going to user profile
	 * 
	 * @return Illuminate\Http\Response
     */ 
    public function index() {

    	$user = auth()->user();
        $achievements = $user->achievements;

        return view('frontend.profile', compact([
            'user',
            'achievements'
        ]));

    }
}
