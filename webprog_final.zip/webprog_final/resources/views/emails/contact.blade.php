<h2>Contact Form Submission</h2>
<p>By: {{ $contactMessage->name }}</p>
<p>Email Address : {{ $contactMessage->email }}</p>
<pre>
	
	{{ $contactMessage->message }}

</pre>