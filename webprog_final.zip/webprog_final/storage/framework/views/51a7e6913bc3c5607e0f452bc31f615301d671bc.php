<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Course - Create</div>

                <div class="panel-body">
                    <form action="<?php echo e(route('course/store')); ?>" method="POST" id="exercise-form">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Course name here..." value="<?php echo e(old('name')); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="slug" class="form-label">Slug</label>
                            <input type="text" name="slug" class="form-control" placeholder="Course Slug here..." value="<?php echo e(old('slug')); ?>">
                            <?php if($errors->has('slug')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('slug')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="course_topic_id" class="form-label">Course Topic</label>
                            <select name="course_topic_id" class="form-control">
                                <?php $__currentLoopData = $courseTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseTopic): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($courseTopic->id); ?>"><?php echo e($courseTopic->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </select>
                            <?php if($errors->has('course_topic_id')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('course_topic_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="10" placeholder="Enter the description here..."><?php echo e(old('description')); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit" class="btn btn-default">Create</button>
                            <a href="<?php echo e(route('course/index')); ?>" class="btn btn-default right">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>