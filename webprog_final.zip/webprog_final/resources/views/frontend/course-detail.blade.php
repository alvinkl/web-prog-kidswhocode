@extends('layouts.master-frontend')

@section('content')
<div class="container">

    <ul class="nav nav-tabs md-pills pills-default" role="tablist">
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#excercise" role="tab"><i class="fa fa-graduation-cap fa-2x"></i> Courses</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#discussion" role="tab"><i class="fa fa-users fa-2x"></i> Diskusi Terbaru</a>
        </li>
      </ul>
      <div class="tab-content">
          <div class="tab-pane fade in active" id="excercise" role="tabpanel">
            <div class="panel-body">
              <div class="media">
                <div class="media-left media-middle">
                  <a href="#">
                    <img class="media-object media-img d-flex mr-3" src="{{ asset('image/' . $course->slug . '.png') }}" alt="html5" style="height: 128px;width: 128px;">
                  </a>
                </div>
                <div class="media-body">
                   <div class="panel-heading"> <a href="{{route('user/courses/index')}}">Course</a> - {{ $course->name }}</div>
                   <div>
                        {!! $course->description !!}
                    </div>
                    <hr>
                    <ul class="list-group">
                        @foreach($exercises as $no => $exercise)
                            <a href="{{route('user/exercise/show', $exercise->slug)}}">
                                <li class="list-group-item">
                                    <div class="row">
                                        <div class="col-md-10">
                                            @if($exercise->users->contains(auth()->user()->id))
                                                <!-- Menandakan sudah selesai-->
                                                {{ ($no + 1) . '. ' . $exercise->name . ' - done' }}
                                            @else
                                                {{ ($no + 1) . '. ' . $exercise->name }}
                                            @endif        
                                        </div>
                                        <div class="col-md-2">
                                            <div style="text-align: right;">
                                                <a href="{{route('user/discussion/index', $exercise->slug)}}" class="btn btn-default">Discussion</a>
                                            </div>  
                                        </div>
                                    </div>
                                </li>
                            </a>
                        @endforeach
                    </ul>
                </div>

                <div class="panel-footer">
                    <a href="{{route('user/courses/index')}}">Kembali ke Courses List</a>
                </div>
                </div>
              </div>
            </div>
          <div class="tab-pane fade" id="discussion" role="tabpanel">
            <div class="panel-heading">Diskusi Terbaru - {{$course->name}}</div>

                <div class="panel-body">
                    @if($latestDiscussions->count() == 0)
                        <h3 class="text-center">Belum ada yang berdiskusi untuk course ini...</h3>
                    @endif

                    <!-- Gambaran aja nanti kayak gini tampilannya -->
                    @foreach($latestDiscussions as $discussion)
                        <ul class="list-group">
                                <a href="{{route('user/discussion/show', ['exerciseSlug' => $discussion->exercise_slug, 'discussionId' => $discussion->discussion_id])}}">
                                    <li class="list-group-item">
                                        <span>{{$discussion->exercise_name}} - </span>                                    
                                        <span>{{ $discussion->title }} {{ $discussion->is_deleted ? '- hidden' : ''}} {{ $discussion->is_closed ? '- closed' : ''}}</span>
                                        <em style="text-align: right; float: right; color: black;">{{ $discussion->username}}, {{ (new DateTime($discussion->created_at))->format('d-m-Y, H:i:s') }}</em>
                                    </li>
                                </a>
                        </ul>
                    @endforeach
                </div>
          </div>
      </div>


</div>
@endsection
