<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseTopic extends Model
{
    protected $fillable = ['name', 'slug'];

    public function courses() {
    	return $this->hasMany(\App\Course::class);
    }
}
