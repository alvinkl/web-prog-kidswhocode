<?php

namespace App;

use Zizaco\Entrust\Traits\EntrustUserTrait;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use EntrustUserTrait;
    use Notifiable;

    private $baseExp = 50;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'username', 'email', 'password', 'level', 'title_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Completed exercises by user
     */
    public function exercises() {
        return $this->belongsToMany(\App\Exercise::class, 'exercise_user', 'user_id', 'exercise_id')->withPivot('user_code');
    }

    public function exerciseCount() {
        return $this->exercises()->count();
    }

    /**
     * Completed exercises by user count, on specific course
     */
    public function exercisesCountByCourseId($courseId)
    {
        return \DB::table('exercise_user')
                    ->join('exercises', 'exercise_user.exercise_id', '=', 'exercises.id')
                    ->join('courses', 'exercises.course_id', 'courses.id')
                    ->where('user_id', $this->id)
                    ->where('courses.id', $courseId)
                    ->count();
    }

    /**
     * Achievements of this user
     */
    public function achievements() {
        return $this->belongsToMany(\App\Achievement::class, 'achievement_user', 'user_id', 'achievement_id');
    }

    /**
     * Current User title
     */
    public function title() {
        return $this->hasOne(\App\Title::class, 'id', 'title_id');
    }

    /**
     * Calculating experience needed to level up 
     */
    public function nextLevelExp() {

        $expNeeded = $this->baseExp;

        for($i = 0; $i < ($this->level); $i++)
            $expNeeded *= 2;

        return $expNeeded;
    }

    /**
     * Leveling user up
     */
    public function levelUp() {

        $this->level++;

        //mencari title id, jika di level ini ada perubahan title maka akan diubah
        $this->title_id = ( \App\Title::where('level', $this->level)->first() == null ? $this->title_id : \App\Title::where('level', $this->level)->first()->id);
        
        $this->save();

    }

    public function hasAchievement($achievementId) {
        $userId = $this->id;
        
        return \DB::table('achievement_user')
                    ->where('user_id', $this->id)
                    ->where('achievement_id', $achievementId)
                    ->count() > 0;
    }

    public function isGreaterScore($score) {

        if($this->typing_score < $score) {
            $this->typing_score = $score;
            $this->save();
            return true;
        }
        return false;

    }
}
