<footer class="footer-distributed">

      <div clas='footer-left'>
        <p class="footer-links">
          <a href="{{route('index')}}">Home</a>
          ·
          <a href="{{route('contact/get')}}">Contact</a>
        </p>
      </div>


      <div class="footer-icons">

        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-github"></i></a>

      </div>


      <div class="footer-left">


        <p class="footer-company-name">BINUS UNIVERSITY</p>
        <p class="footer-company-name">Email: kids_who_code@email.com</p>
        <p class="footer-company-name"><strong>Kids Who Code © 2016</strong></p>

      </div>

    </footer>