<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Courses</div>

                <div class="panel-body">
                	<!-- Gambaran aja nanti kayak gini tampilannya -->
                    <?php $__currentLoopData = $courseTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseTopic): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <h3><?php echo e($courseTopic->name); ?></h3>
                        <hr>
                        <ul class="list-group">
                            <?php $__currentLoopData = $courseTopic->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <a href="<?php echo e(route('user/course', $course->slug)); ?>">
                                    <li class="list-group-item">
                                        <img style="width: 25px; height: 25px;" src="<?php echo e(asset('image/' . $course->slug . '.png')); ?>"> <?php echo e($course->name); ?>

                                    </li>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">Diskusi Terbaru</div>

                <div class="panel-body">
                    <?php if($latestDiscussions->count() == 0): ?>
                        <h3 class="text-center">Belum ada yang berdiskusi saat ini...</h3>
                    <?php endif; ?>

                    <!-- Gambaran aja nanti kayak gini tampilannya -->
                    <?php $__currentLoopData = $latestDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <ul class="list-group">
                            <a href="<?php echo e(route('user/discussion/show', ['exerciseSlug' => $discussion->exercise->slug, 'discussionId' => $discussion->id])); ?>">
                                <li class="list-group-item">
                                    <span><?php echo e($discussion->exercise->course->name); ?> - </span>                                    
                                    <span><?php echo e($discussion->title); ?>  <?php echo e($discussion->is_deleted ? '- hidden' : ''); ?> <?php echo e($discussion->is_closed ? '- closed' : ''); ?></span>
                                    <em style="text-align: right; float: right; color: black;"><?php echo e($discussion->starter->username); ?>, <?php echo e($discussion->created_at->format('d-m-Y, H:i:s')); ?></em>
                                </li>
                            </a>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>