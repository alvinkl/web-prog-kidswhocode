@extends('layouts.master-frontend')

<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Typing game</title>
  <link href='https://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.3/animate.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="{{ asset('css/typing-style.css')}}">

@section('content')
  <div class="wrapper">
    <h1 style="color: #2ecc71;">Typing game < Smarter Code ></h1>
    <button id='start'>START</button>
    <div class="outerWrap">
      <div class="scoreWrap">
        <p>Score</p>
        <span class="score">0</span>
      </div>
      <div class="timeWrap">
        <p>Time left</p>
        <span class="time">60</span>
      </div>
    </div>
    <div class="wordsWrap">
      <p class="words"></p>
    </div>
  </div>

    <div class="container">
      <!-- Modal -->
      <div class="modal fade" id="modal" role="dialog">
        <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Great Job!</h4>
            </div>
            <div class="modal-body">
              <div id='modaltxt'></div>
              <div id='total'>Total Point : </div>
            </div>
            <div class="modal-footer">
              <button id='restart'>RESTART</button>
            </div>
          </div>

        </div>
      </div>
    </div>
@endsection

@section('additional-script')
    <script>
        var userid = -1;
        @if(!Auth::guest())
          userid = '{{ auth()->user()->id }}';
        @endif
    </script>
    <script src='{{asset('js/typing-script.js')}}'></script>
@endsection