<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discussion extends Model
{
    protected $fillable = ['user_id', 'exercise_id', 'title', 'content', 'is_closed', 'is_deleted'];

	/**
	 * Each discussion has many posts
	 */
    public function posts() {
    	return $this->hasMany(\App\DiscussionPost::class);
    }

    /**
     * Each discussion belongs to an exercise
     */
    public function exercise() {
    	return $this->belongsTo(\App\Exercise::class);
    }

    /**
     * Each discussion has one user as a discussion starter 
     */
    public function starter() {
        return $this->hasOne(\App\User::class, 'id', 'user_id');
    }

    /**
     * By closed, it means that user may not reply it anymore
     */
    public function close() {
        $this->is_closed = true;
        $this->save();
    }

    /**
     * By unclosed, it mean sthat user may reply it once more
     */
    public function unclose() {
        $this->is_closed = false;
        $this->save();
    }

    /**
     * By unhide, it means that the post will be shown once more
     */
    public function unhide() {
        $this->is_deleted = false;
        $this->save();
    }

    /**
     * By delete, it means hides it from user
     */
    public function hide() {
        $this->is_deleted = true;
        $this->save();
    }
}
