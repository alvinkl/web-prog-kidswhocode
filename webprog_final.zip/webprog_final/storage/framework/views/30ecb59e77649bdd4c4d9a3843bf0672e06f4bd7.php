<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content">
            Page Not Found, <a href="<?php echo e(url()->previous()); ?>">Click here</a> to go back
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>