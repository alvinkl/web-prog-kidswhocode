<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Title</div>

                <div class="panel-body">
                    <table id="title-table" class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Level</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($title->id); ?></td>
                                    <td><?php echo e($title->name); ?></td>
                                    <td><?php echo e($title->level); ?></td>
                                    <td><a href="<?php echo e(route('title/edit', $title->id)); ?>" class="btn btn-default">Update</a></td>
                                    <td>
                                        <form action="<?php echo e(route('title/destroy', $title->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="btn btn-default">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="panel-footer">
                    <a class="btn btn-default" href="<?php echo e(route('title/create')); ?>">Create new Title</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-script'); ?>
    <script>
        $(document).ready(function() {
            $('#title-table').DataTable();
        });          
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>