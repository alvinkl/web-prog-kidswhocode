<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscussionPost extends Model
{
	protected $fillable = ['discussion_id', 'user_id', 'content'];

	/**
	 * Each discussion post belongs to a discussion
	 */
    public function discussion() {
    	return $this->belongsTo(\App\Discussion::class);
    }

    /**
     * Getting the poster
     */
    public function user() {
    	return $this->belongsTo(\App\User::class, 'user_id', 'id');
    }
}
