<?php if(session()->has('flash_message')): ?>
	<div id="flash-message" class="alert alert-<?php echo e(session()->get('flash_type')); ?>">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<?php echo e(session()->get('flash_message')); ?>

	</div>
<?php endif; ?>
